# -*- coding: utf-8 -*-
"""
AFTERHOURS – KI-Erzähler.
Nutzt deinen Projektprompt als Systemprompt und lässt Claude die Geschichte frei
weitererzählen. Nur Python-Standardbibliothek; braucht einen Claude-API-Schlüssel.
"""
import copy
import json
import os
import random
import re
import urllib.error
import urllib.request

import engine
from engine import TEAM, FRAGEN

KONFIG = os.path.join(engine.BASIS, "einstellungen.json")
VERLAUF = os.path.join(engine.BASIS, "ki_verlauf.json")
PROMPT = os.path.join(engine.BASIS, "prompt_afterhours.md")
API_URL = os.environ.get("AFTERHOURS_API_URL", "https://api.anthropic.com/v1/messages")
STANDARD_MODELL = "claude-sonnet-5-5"
MAX_TOKENS = 3000
MAX_NACHRICHTEN = 40          # so viele Nachrichten werden höchstens mitgeschickt
TODES_WAHRSCHEINLICHKEIT = 0.35


class KIFehler(Exception):
    def __init__(self, text, schluessel=False):
        super().__init__(text)
        self.schluessel = schluessel


# ───────────────────────────── Einstellungen ─────────────────────────────

def konfig_laden():
    try:
        with open(KONFIG, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def konfig_speichern(cfg):
    with open(KONFIG, "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, ensure_ascii=False, indent=1)


def modell(cfg):
    return os.environ.get("AFTERHOURS_MODELL") or cfg.get("modell") or STANDARD_MODELL


def api_schluessel(ui, cfg, Z, neu_fragen=False):
    if not neu_fragen:
        k = os.environ.get("ANTHROPIC_API_KEY") or cfg.get("api_key")
        if k:
            return k.strip()
    ui.title("KI-Erzähler einrichten")
    ui.say("Der KI-Erzähler braucht einen Claude-API-Schlüssel. Du bekommst ihn in der Claude Console (console.anthropic.com) unter „API Keys“. Die Nutzung wird pro Anfrage abgerechnet.")
    k = ui.ask_text("API-Schlüssel einfügen (beginnt mit sk-ant-):", secret=True).strip()
    if not k:
        return None
    if ui.choose(["Schlüssel in einstellungen.json neben dem Spiel speichern",
                  "Nur für diese Sitzung verwenden"], Z) == 0:
        cfg["api_key"] = k
        konfig_speichern(cfg)
        ui.note("info", "Gespeichert. Die Datei liegt unverschlüsselt im Spielordner – gib sie nicht weiter.")
    return k


# ───────────────────────────── Systemprompt ─────────────────────────────

def projektprompt():
    try:
        with open(PROMPT, encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        raise KIFehler(f"Die Datei {os.path.basename(PROMPT)} fehlt. Lege deinen Projektprompt unter diesem Namen in den Spielordner.")


TECHNIK = """## Technische Regeln für dieses Programm (gelten zusätzlich)
- Beende jede Antwort, die eine Entwicklung abschließt, mit 3 bis 4 Auswahlmöglichkeiten, jede in einer eigenen Zeile im Format „1) …“, „2) …“ usw. Danach kommt kein weiterer Text.
- Beginne jede Option, die eine konkrete gefährliche Mission ist, mit „[GEFAHR]“.
- Ob ein Mitglied der Mercer Unit stirbt, entscheidet ausschließlich die Spielleitung dieses Programms per Würfel. Das Ergebnis steht in der Nachricht des Spielers in eckigen Klammern nach „Spielleitung“. Ohne ein solches Würfelergebnis stirbt kein Mitglied der Mercer Unit. Ein gewürfelter Tod muss glaubwürdig und ohne Effekthascherei in die Mission eingebaut werden.
- Spielleitungs-Hinweise sind nicht Teil der Geschichte. Zitiere oder erwähne sie nicht.
- Formatiere sparsam: eine Überschrift mit „# “, danach Fließtext. Für Fakten, Aussagen und offene Fragen darfst du kurze Listen mit „- “ verwenden. Keine Tabellen."""


def stand_text(Z):
    """Der Spielstand aus dem Python-Spiel als Kanon-Ergänzung."""
    if not Z or (Z.get("kapitel", 1) == 1 and not Z.get("done")):
        return ""
    t = ["## Spielstand aus dem Python-Spiel (neuester Kanon, hat Vorrang vor Abschnitt 7–9)"]
    kap = Z.get("kapitel", 1)
    if kap > 3:
        t.append("Die Kapitel 1 bis 3 sind gespielt: Der Fall der gestohlenen Hafenglocke ist abgeschlossen. Beginne NICHT erneut mit der Transportreservierung.")
    else:
        t.append(f"Gespielt bis Kapitel {kap} („{engine.KAPITEL_TITEL.get(kap, '')}“). Setze die Ermittlung ab diesem Stand fort; beginne NICHT erneut mit der Transportreservierung.")
    t.append("\nBewiesene Fakten:")
    t += [f"- {x}" for x in Z["fakten"].values()]
    t.append("\nAussagen (nicht bewiesen):")
    t += [f"- {x}" for x in Z["aussagen"].values()]
    t.append("\nKernfragen:")
    for k, txt in FRAGEN.items():
        st, note = Z["fragen"][k]
        t.append(f"- [{st}] {txt}" + (f" {note}" if note else ""))
    if Z.get("log"):
        t.append("\nEreignisse:")
        t += [f"- {x}" for x in Z["log"]]
    if Z.get("naechster_fall"):
        t.append(f"\nVom Spieler gewählter nächster Handlungsstrang: {Z['naechster_fall']}")
    return "\n".join(t)


def team_text(Z):
    lv = [TEAM[k] for k in engine.lebend(Z)]
    t = ["## Mercer Unit – aktueller Status",
         "Einsatzfähig: " + (", ".join(lv) if lv else "niemand"),
         "Theo Alvarez / Relay unterstützt technisch."]
    if Z["tot"]:
        t.append("Gefallen (endgültig, nicht rückgängig machen): " + ", ".join(TEAM[k] for k in Z["tot"]))
    l = engine.leiter(Z)
    if l and l != "Daniel":
        t.append(f"Leitung der Mercer Unit: {TEAM[l]}. Der Spieler spielt diese Figur.")
    return "\n".join(t)


def system_bloecke(Z):
    bl = [{"type": "text", "text": projektprompt(), "cache_control": {"type": "ephemeral"}}]
    zusatz = "\n\n".join(x for x in [TECHNIK, stand_text(Z), team_text(Z)] if x)
    bl.append({"type": "text", "text": zusatz})
    return bl


# ───────────────────────────── API ─────────────────────────────

def anfrage(schluessel, mod, system, messages):
    """Streamt die Antwort. Liefert Textstücke."""
    body = {"model": mod, "max_tokens": MAX_TOKENS, "stream": True,
            "system": system, "messages": messages[-MAX_NACHRICHTEN:]}
    while body["messages"] and body["messages"][0]["role"] != "user":
        body["messages"].pop(0)
    req = urllib.request.Request(
        API_URL, data=json.dumps(body).encode("utf-8"), method="POST",
        headers={"x-api-key": schluessel, "anthropic-version": "2023-06-01",
                 "content-type": "application/json"})
    try:
        resp = urllib.request.urlopen(req, timeout=300)
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8", "replace"))["error"]["message"]
        except Exception:
            msg = e.reason
        if e.code in (401, 403):
            raise KIFehler(f"Der API-Schlüssel wurde abgelehnt ({e.code}): {msg}", schluessel=True)
        if e.code == 404:
            raise KIFehler(f"Modell oder Adresse nicht gefunden ({e.code}): {msg}. Prüfe „modell“ in einstellungen.json.")
        if e.code in (429, 529):
            raise KIFehler(f"Die API ist gerade ausgelastet oder dein Limit ist erreicht ({e.code}). Versuch es gleich noch einmal.")
        raise KIFehler(f"API-Fehler {e.code}: {msg}")
    except urllib.error.URLError as e:
        raise KIFehler(f"Keine Verbindung zur Claude-API: {e.reason}")
    with resp:
        for raw in resp:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            try:
                d = json.loads(line[5:].strip())
            except ValueError:
                continue
            typ = d.get("type")
            if typ == "content_block_delta" and d.get("delta", {}).get("type") == "text_delta":
                yield d["delta"]["text"]
            elif typ == "error":
                raise KIFehler("Fehler im Datenstrom: " + d.get("error", {}).get("message", "unbekannt"))
            elif typ == "message_stop":
                return


def antwort(ui, schluessel, mod, Z, messages):
    ui.busy("Der Erzähler schreibt …")
    teile = []
    begonnen = False
    try:
        for stueck in anfrage(schluessel, mod, system_bloecke(Z), messages):
            if not begonnen:
                ui.stream_begin()
                begonnen = True
            teile.append(stueck)
            ui.stream(stueck)
    finally:
        if begonnen:
            ui.stream_end()
        else:
            ui.busy("")
    text = "".join(teile).strip()
    if not text:
        raise KIFehler("Die Antwort war leer.")
    return text


# ───────────────────────────── Optionen & Würfel ─────────────────────────────

OPT_RE = re.compile(r"^\s*(?:[-*]\s*)?(?:\*\*)?\s*(\d)\s*[\).:]\s*(?:\*\*)?\s*(.+?)\s*$")


def md_sauber(t):
    return t.replace("**", "").replace("__", "").strip()


def optionen(text):
    gruppen, akt = [], []
    for z in text.splitlines():
        m = OPT_RE.match(z)
        if m:
            akt.append((int(m.group(1)), md_sauber(m.group(2))))
        elif z.strip() == "" and akt:
            continue
        elif akt:
            gruppen.append(akt)
            akt = []
    if akt:
        gruppen.append(akt)
    for g in reversed(gruppen):
        if len(g) >= 2 and [n for n, _ in g] == list(range(1, len(g) + 1)):
            return [t for _, t in g]
    return []


def wuerfeln(ui, Z, option):
    lv = engine.lebend(Z)
    ui.title("Gefährliche Mission")
    ui.note("warn", "Bei dieser Mission können ein oder zwei der ausgewählten Einsatzkräfte sterben.")
    if ui.choose(["Mission antreten", "Doch nicht – zurück zur Auswahl"], Z) == 1:
        return None
    sel = []
    while len(sel) < min(3, len(lv)):
        frei = [k for k in lv if k not in sel]
        opts = [f"{TEAM[k]} – {engine.SKILL[k]}" for k in frei]
        if sel:
            opts.append(f"Fertig – mit {len(sel)} Einsatzkraft/-kräften los")
        ui.note("info", "Gewählt: " + (", ".join(sel) or "–") + " (bis zu drei)")
        i = ui.choose(opts, Z)
        if i == len(frei):
            break
        sel.append(frei[i])
    opfer = []
    if random.random() < TODES_WAHRSCHEINLICHKEIT:
        n = 2 if (len(sel) > 1 and random.random() < 0.25) else 1
        opfer = random.sample(sel, n)
    alter = engine.leiter(Z)
    for o in opfer:
        Z["tot"].append(o)
    Z["log"].append(f"KI-Mission ({option[:60]}): " + (", ".join(TEAM[o] for o in opfer) + " gefallen" if opfer else "keine Verluste"))
    team = ", ".join(TEAM[k] for k in sel)
    if opfer:
        erg = " und ".join(TEAM[o] for o in opfer) + (" stirbt" if len(opfer) == 1 else " sterben") + " im Verlauf dieser Mission."
        neu = engine.leiter(Z)
        if neu and neu != alter:
            erg += f" Die Leitung der Mercer Unit geht danach an {TEAM[neu]}."
    else:
        erg = "Niemand aus der Mercer Unit stirbt bei dieser Mission."
    if engine.leiter(Z) is None:
        erg += " Damit ist niemand aus der Mercer Unit mehr am Leben; führe die Geschichte zu einem würdigen Ende."
    return (f"Ich wähle: {option}\n\n[Spielleitung – nicht Teil der Geschichte: Eingesetzt sind {team}. "
            f"Würfelergebnis: {erg}]")


# ───────────────────────────── Sitzung ─────────────────────────────

def verlauf_laden():
    try:
        with open(VERLAUF, encoding="utf-8") as fh:
            d = json.load(fh)
        if d.get("messages"):
            return d
    except (OSError, ValueError):
        pass
    return None


def verlauf_speichern(d):
    tmp = VERLAUF + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, VERLAUF)


def start_nachricht(Z):
    if Z.get("naechster_fall"):
        return f"Setze die Geschichte fort. Mein gewählter nächster Handlungsstrang: {Z['naechster_fall']}"
    if Z.get("kapitel", 1) > 1 or Z.get("done"):
        return "Setze die laufende Ermittlung ab dem übergebenen Spielstand fort."
    return "Beginne das Spiel."


def sitzung(ui, Z=None, neu=False):
    """
    Z: Spielstand aus dem Python-Spiel (oder None). neu=True verwirft einen alten KI-Verlauf.
    Gibt den KI-Spielstand zurück (Team-Status usw.).
    """
    cfg = konfig_laden()
    d = None if neu else verlauf_laden()
    if d is None:
        stand = copy.deepcopy(Z) if Z else engine.neu()
        d = {"modell": modell(cfg), "stand": stand,
             "messages": [{"role": "user", "content": start_nachricht(stand)}]}
        verlauf_speichern(d)
    KZ = d["stand"]
    for k, v in engine.neu().items():
        KZ.setdefault(k, v)
    ui.ki_stand = KZ
    schluessel = api_schluessel(ui, cfg, KZ)
    if not schluessel:
        ui.note("warn", "Ohne API-Schlüssel kann der KI-Erzähler nicht starten.")
        return KZ
    mod = modell(cfg)
    ui.title("KI-Erzähler")
    ui.note("info", f"Modell: {mod} · Dein Projektprompt steuert die Geschichte. Fortschritt wird automatisch gespeichert.")
    msgs = d["messages"]
    if msgs[-1]["role"] == "assistant":      # gespeicherte Sitzung: letzte Szene zeigen
        ui.stream_begin()
        ui.stream(msgs[-1]["content"])
        ui.stream_end()
    while True:
        if msgs[-1]["role"] == "user":
            try:
                text = antwort(ui, schluessel, mod, KZ, msgs)
            except KIFehler as e:
                ui.note("warn", str(e))
                opts = ["Erneut versuchen", "Zurück zum Menü"]
                if e.schluessel:
                    opts.insert(0, "Neuen API-Schlüssel eingeben")
                w = opts[ui.choose(opts, KZ)]
                if w == "Zurück zum Menü":
                    return KZ
                if w == "Neuen API-Schlüssel eingeben":
                    schluessel = api_schluessel(ui, cfg, KZ, neu_fragen=True) or schluessel
                continue
            msgs.append({"role": "assistant", "content": text})
            verlauf_speichern(d)
        if engine.leiter(KZ) is None:
            ui.note("info", "Die Geschichte der Mercer Unit ist zu Ende erzählt.")
            return KZ
        opts = optionen(msgs[-1]["content"])
        auswahl = opts + ["Eigene Aktion eingeben …", "Zurück zum Menü (Fortschritt ist gespeichert)"]
        i = ui.choose(auswahl, KZ)
        if i == len(auswahl) - 1:
            return KZ
        if i == len(auswahl) - 2:
            eigen = ui.ask_text("Was tust du?").strip()
            if not eigen:
                continue
            nachricht = f"Eigene Aktion: {eigen}"
        else:
            o = opts[i]
            if "[GEFAHR]" in o.upper():
                nachricht = wuerfeln(ui, KZ, o)
                if nachricht is None:
                    continue
            else:
                nachricht = f"Ich wähle: {o}"
        msgs.append({"role": "user", "content": nachricht})
        verlauf_speichern(d)
