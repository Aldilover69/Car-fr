#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AFTERHOURS – Startdatei.

  python afterhours.py              Grafikversion (falls pygame installiert ist)
  python afterhours.py --terminal   Terminalversion
  python afterhours.py --selbsttest Prüft Grafik, Geschichte und Claude-API auf diesem Rechner
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    if "--selbsttest" in sys.argv:
        import selbsttest
        sys.exit(selbsttest.main())
    if "--terminal" in sys.argv or "-t" in sys.argv:
        import terminal
        terminal.hauptmenue()
        return
    try:
        import pygame  # noqa: F401
    except ImportError:
        print("pygame ist nicht installiert – die Terminalversion startet.")
        print("Für die Grafikversion:  pip install pygame\n")
        import terminal
        terminal.hauptmenue()
        return
    import gui
    gui.main()


if __name__ == "__main__":
    main()
