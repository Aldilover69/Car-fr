# -*- coding: utf-8 -*-
"""AFTERHOURS – Kapitel 2: Drei Striche im Kreis."""
from engine import (L, TEAM, aussage, fakt, frage, gefahr_mission, hat, setf)
import kapitel1

ROLLEN_MAELZEREI = {"Statik": ["Mara", "Daniel"], "Licht": ["Imani", "Asha"],
                    "Rettung": ["Leila", "Nico", "Juno"]}
MAELZEREI_ZEILE = {
    "Daniel": "Daniel geht als Erster durch die Tür – jede Erschütterung, die er abfängt, trifft das Gebäude nicht.",
    "Mara": "Mara legt die Hand an die gusseiserne Säule im Darrboden und verankert sie, bevor jemand anderes es tun kann.",
    "Nico": "Nico macht den Treppenabsatz griffig und die Rampe an der Hintertür zur Rutschbahn – hinein kommt man, hinaus nicht.",
    "Asha": "Asha dämpft die Schritte der Beamten und fokussiert, was oben passiert: zwei Stimmen, ein Kratzen an Mauerwerk.",
    "Imani": "Imani speist die Baustrahler über die alte Leitung direkt in die Halle – was jemand dimmt, drückt sie nach.",
    "Leila": "Leila bleibt dicht hinter dem Zugriffstrupp, die Hände frei.",
    "Juno": "Juno nimmt den Weg über die Lüftungsgauben und sieht den Darrboden von oben.",
}
MAELZEREI_TOD = {
    "Daniel": "Als der Darrboden reißt, fängt Daniel den Sturz der Decke ab – mehr, als er speichern kann.",
    "Mara": "Mara hält die Säule, bis der Boden um sie herum nachgibt.",
    "Nico": "Nico zieht einen Beamten von der Kante. Er selbst findet keinen Halt mehr.",
    "Asha": "Asha hört den Riss als Erste und warnt die anderen. Für sich selbst bleibt keine Sekunde.",
    "Imani": "Imani ist noch an der Leitung, als die Wand mit den Kabeln darin einbricht.",
    "Leila": "Leila kniet bei einem verletzten Beamten, als die Trümmer fallen. Sie lässt ihn nicht los.",
    "Juno": "Juno springt dem Einsturz hinterher, um jemanden zu erreichen. Die letzte Trittfläche trägt, die Landung nicht.",
}


# ───────────────────────────── Auftakt ─────────────────────────────

def auftakt(ui, Z):
    ui.kapitel_karte(2, "Drei Striche im Kreis", "Wer hat die Glocke aus dem Museum geholt?")
    ui.ort("Präsidium Vesper · 09:40 Uhr, am Morgen nach der Lieferung")
    if Z["tier"] == "A":
        ui.say("Elise Vardon hat die Nacht in Gewahrsam verbracht; am Mittag entscheidet der Haftrichter. Auf Wynns Schreibtisch liegt der erste Bericht der IT-Forensik zu ihrem Telefon.")
        ui.talk("Wynn", "Zweite SIM-Karte im Telefon. Rate mal, welche Nummer.")
        fakt(ui, Z, "vardon_sim", "In Vardons beschlagnahmtem Telefon steckt eine zweite SIM-Karte – die Nummer des Chat-Gegenübers auf Danes Telefon. Aktiviert am Tag nach dem Diebstahl um 15:58 Uhr.")
        setf(Z, "nummer_id", "ev_id")
        if hat(Z, "dane_rusk_behauptung"):
            fakt(ui, Z, "dane_luege", "Danes Aussage, das Chat-Gegenüber sei der Fahrer Rusk gewesen, ist widerlegt.")
        ui.talk("Wynn", "Um 16:40 Uhr unterschreibt sie den Mietvertrag. Um 21:12 Uhr schreibt sie Dane, es sei vorbei, wenn die Glocke wirklich aus dem Museum stammt. Und gestern früh steht sie trotzdem in der Halle und hebt den Deckel. Irgendwas ist zwischen diesen Uhrzeiten passiert.")
        frage(ui, Z, "ev", "geklärt", "„E. V.“ ist Elise Vardon; die Prepaid-Nummer im Chat mit Dane steckt als zweite SIM in ihrem Telefon.")
    elif Z["tier"] == "B":
        ui.say("Elise Vardon ist zu Hause. Ihre Aussage von gestern liegt auf Wynns Tisch: drei Seiten Unwissen und Verwechslung, sauber formuliert von einem teuren Anwalt.")
        ui.talk("Wynn", "Ich glaube ihr die Hälfte. Die Frage ist, welche Hälfte. Für einen Haftbefehl reicht es nicht – noch nicht.")
    else:
        ui.say("Die Buchung wurde storniert, niemand kam. Die Glocke ist zurück, aber die Käuferseite hat sich in Luft aufgelöst. Wynn hat drei Stunden geschlafen und sieht aus wie sechs Minuten.")
        ui.talk("Wynn", "Dann arbeiten wir uns von der anderen Seite heran.")
    ui.talk("Wynn", "Es gibt die Käuferseite und es gibt die Täterseite. Jemand hat in einer Dienstagnacht die Wand im Museum aufgemacht, eine Glocke von 140 Kilo herausgeholt und einen Wachmann verletzt zurückgelassen. Rusk ist Fahrer, Dane ist Vermittler. Keiner von beiden kann durch Wände gehen.")
    ui.pause()


# ───────────────────────────── Spuren ─────────────────────────────

def k2_einbruch(ui, Z):
    ui.title("Stadtmuseum Vesper")
    ui.ort("Hafensaal und hinterer Wirtschaftsgang")
    ui.say("Sanna Revik trägt Baumwollhandschuhe, obwohl es hier nichts mehr anzufassen gibt. Der Sockel, an dem die Hafenglocke hing, ist leer; die Messingbeschläge sind abgeschraubt, nicht abgerissen. Wynn hat die Unit dazugebeten – Fachwissen über Kräfte, nicht über Tatorte, hat er am Telefon gesagt.")
    ui.talk("Revik", "Die Beschläge hat jemand geduldig gelöst. Jemand, der wusste, dass die Glocke 140 Kilo wiegt und dass man sie nicht schleift.")
    ui.say("Im Wirtschaftsgang klafft ein schulterbreites Loch in der Wand. Es folgt einer Naht, die heller ist als das übrige Mauerwerk – eine Reparatur aus den Fünfzigern.")
    ui.talk("Wynn", "Keine Bohrlöcher, keine Meißelspuren. Die Bruchkanten laufen an der alten Mörtelfuge entlang wie an einer Perforation. Was sagt die Unit?")
    ui.talk(L(Z), "Das war keine Maschine. Jemand hat Risse erzeugt, genau dort, wo die Wand schon schwach war. Ich kenne in Vesper genau eine Person, die so arbeitet. Aber eine Signatur ist kein Beweis.")
    ui.talk("Wynn", "Nein. Aber das hier vielleicht.")
    ui.say("Er hebt einen Asservatenbeutel: ein Arbeitshandschuh, grau von Mörtelstaub, gefunden im Abflussgitter des Gangs.")
    ui.talk("Revik", "Und dann das Licht. Die Sensoren im Gang: von 02:11 bis 02:15 Uhr fällt die Helligkeit um siebzig Prozent – aber nur in einem Umkreis von etwa sechs Metern. Der Saal daneben bleibt normal. Auf der Kamera sieht man graue Suppe.")
    ui.talk("Wynn", "Kein Stromausfall. Jemand hat das Licht geschluckt.")
    ui.say("Wynn liest aus der Aussage, die der Wachmann Tomas Brehm im Krankenhaus gemacht hat: ein Knacken wie Eis auf einem Teich, dann die Stimme einer Frau – ‚Zurück!‘ – und dann kam ihm die Wand entgegen. Gefunden hat ihn erst die Frühschicht.")
    ui.talk("Wynn", "Sie hat ihn gewarnt. Und dann liegen lassen. Das ist entweder Gewissen oder Feigheit. Vermutlich beides.")
    ui.talk("Revik", "Noch etwas, weil Sie nach Interessenten fragten: Cairn Maritime hat vor drei Wochen um eine Dauerleihgabe gebeten. Für das Firmenfoyer. Ich habe abgelehnt. Die Glocke gehört an den Westkai, nicht in eine Lobby.")
    fakt(ui, Z, "wand", "Museum, hinterer Wirtschaftsgang: Mauer entlang einer alten Reparaturnaht ausgebrochen, ohne Werkzeugspuren; Beschläge der Glocke fachgerecht gelöst.")
    fakt(ui, Z, "licht", "Lichtsensoren: 02:11 bis 02:15 Uhr Helligkeit im Wirtschaftsgang um ca. 70 % gesenkt, auf rund sechs Meter Umkreis begrenzt; kein Stromausfall.")
    fakt(ui, Z, "handschuh_fund", "Arbeitshandschuh mit Mörtelstaub im Abflussgitter des Wirtschaftsgangs sichergestellt; DNA-Analyse läuft.")
    aussage(ui, Z, "brehm", "Wachmann Tomas Brehm: hörte ein Knacken, dann rief eine Frau „Zurück!“, bevor das Mauerwerk ihn traf; gefunden wurde er von der Frühschicht.")
    aussage(ui, Z, "revik_leihe", "Sanna Revik: Cairn bat vor drei Wochen um eine Dauerleihgabe der Glocke für das Firmenfoyer; sie lehnte ab.")
    setf(Z, "kess_spur", "kess_reue", "sen_spur")
    frage(ui, Z, "org", "teilweise", "Die Spuren passen zu einer Riss- und einer Lichtfähigkeit – Signaturen, noch keine Identifizierung.")


def k2_rusk(ui, Z):
    ui.title("Vernehmungsraum 3")
    ui.ort("Kellan Rusk")
    ui.say("Rusk ist Ende vierzig, hat die Hände eines Mannes, der Paletten schiebt, und das Gesicht eines Mannes, der gerade begreift, wie tief er drinsteckt. Sein Pflichtverteidiger hat ihm geraten zu reden. Diesmal hört er zu.")
    ui.talk("Rusk", "Dane hat mich am Morgen nach dem Einbruch angerufen. Neunhundert für eine Fahrt: Zollhof, Halle C, dann Tor 4. Nicht reinschauen, nicht fragen. Ich hab nicht reingeschaut.")
    ui.talk("Wynn", "Wer war in Halle C?")
    ui.talk("Rusk", "Zwei. Eine Frau, Arbeitshandschuhe, Kalkstaub bis an die Ellbogen. Und ein dünner Typ, der kein Wort gesagt hat. Als ich in den Hof gefahren bin, wurde das Licht dunkler. Nicht aus – dunkler. Als würde einer am Dimmer drehen.")
    ui.talk("Rusk", "Beim Einladen hat die Frau gesagt: ‚Sag dem Treuhänder, die Mauer war morsch. Ich wollte nicht, dass einer was abkriegt.‘ Ich dachte, das geht mich nichts an. War wohl falsch.")
    ui.say("Wynn legt den Ausdruck des Chats auf den Tisch: ‚Ich habe dem Transport zugestimmt, nicht dem Diebstahl.‘")
    ui.talk("Rusk", "Das bin ich nicht. Ich schreib Dane nicht, ich telefonier mit ihm. Und das ist nicht meine Nummer. Gucken Sie nach.")
    ui.say("Wynn guckt nach. Es ist nicht seine Nummer – weder die auf dem Diensthandy noch die private.")
    ui.talk("Rusk", "Und die neunhundert kamen nicht von Dane. Kam über so einen Code. T-R-H und eine Sieben.")
    fakt(ui, Z, "zahlung_trh7", "Rusks Fahrlohn (900 VC) wurde über den Vermittlungscode TRH-7 bezahlt – nicht über Danes Code.")
    fakt(ui, Z, "chat_nicht_rusk", "Die Nummer des Chat-Gegenübers auf Danes Telefon gehört zu keinem von Rusks Anschlüssen.")
    if hat(Z, "dane_rusk_behauptung"):
        fakt(ui, Z, "dane_luege", "Danes Aussage, das Chat-Gegenüber sei der Fahrer Rusk gewesen, ist widerlegt.")
    aussage(ui, Z, "rusk", "Rusk: Dane beauftragte ihn am Morgen nach dem Einbruch (Zollhof Halle C nach Tor 4, 900 VC); in Halle C warteten eine Frau mit Arbeitshandschuhen und Kalkstaub und ein schweigsamer Mann, das Hoflicht wurde „gedimmt“; die Frau sagte: „Sag dem Treuhänder, die Mauer war morsch.“")
    ui.say("Noch am Vormittag schickt Wynn die Spurensicherung in den Zollhof.")
    fakt(ui, Z, "zollhof", "Zollhof Halle C: Bronzeabrieb und Mörtelstaub auf dem Boden; die Halle war für zwei Wochen bar angemietet worden.")
    setf(Z, "kess_spur", "kess_reue", "sen_spur", "treuhaender", "trh7")
    frage(ui, Z, "org", "teilweise", "Der Fahrlohn kam über TRH-7, den Code des „Treuhänders“; in Halle C warteten zwei Unbekannte mit Riss- und Lichtsignatur.")


def k2_quist(ui, Z):
    ui.title("Quist Antiquitäten")
    ui.ort("Hafenstraße 31")
    ui.say("Nella Quist führt ihren Laden wie ein Archiv: Jedes Stück hat eine Karteikarte, jede Karteikarte eine Geschichte. Wynn hat dich gebeten, vorn im Laden die Straße im Blick zu behalten – Quist hat Bekannte, die ihr diesen Besuch übelnehmen könnten. Die Tür zum Hinterzimmer bleibt einen Spalt offen.")
    ui.talk("Quist", "Ivo Serrat war vor fünf Wochen hier. Er hat gefragt, was die Westkai-Glocke einem Sammler wert wäre. Und wer zahlen würde, ohne nach Papieren zu fragen. Ich habe ihm Tee angeboten und dann die Tür gezeigt.")
    ui.talk("Wynn", "Warum erzählen Sie mir das jetzt?")
    ui.talk("Quist", "Weil ein Wachmann im Krankenhaus liegt. Ich verkaufe alte Dinge, Detective. Ich verkaufe keine Leute.")
    ui.say("Sie legt ihr Telefon auf den Tisch und spielt eine Sprachnachricht ab, gespeichert, nie gelöscht. Eine höfliche, warme Stimme fragt – nur hypothetisch –, wen Nella anrufen würde, wenn die Glocke vom Westkai den Besitzer wechselte.")
    ui.talk("Quist", "Serrat nennt sich ‚Treuhänder‘, wenn ein Kunde saubere Hände will. Er arbeitet mit einer Frau, die man auf der Seitenlinie ‚die Wandleserin‘ nennt, und mit einem, den sie ‚den Lichtschlucker‘ nennen. Namen kenne ich nicht. Und vor Gericht sage ich nicht mehr, als ich weiß.")
    fakt(ui, Z, "sprachnachricht", "Sprachnachricht von Ivo Serrats bekannter Nummer an Nella Quist, fünf Wochen vor dem Diebstahl: Frage, wen man anrufen würde, wenn „die Glocke vom Westkai“ den Besitzer wechselt.")
    aussage(ui, Z, "quist", "Nella Quist: Serrat fragte vor fünf Wochen nach Wert und diskreten Käufern für die Glocke; er nenne sich „Treuhänder“ und arbeite mit der „Wandleserin“ und dem „Lichtschlucker“ aus dem Umfeld der Seitenlinie.")
    setf(Z, "serrat_name", "treuhaender", "kess_spur", "sen_spur")
    frage(ui, Z, "org", "teilweise", "Verdacht gegen Ivo Serrat als „Treuhänder“ – belegt ist bisher nur sein Interesse an der Glocke vor dem Diebstahl.")


def k2_cairn(ui, Z):
    ui.title("Cairn Maritime Holdings")
    ui.ort("Konzernzentrale am Ankerplatz")
    ui.say("Dr. Ilse Martell, Leiterin der Compliance, empfängt Wynn ohne Anwalt und mit drei Ordnern. ‚Wir wollen das nicht in der Zeitung lesen, bevor wir es selbst verstanden haben‘, sagt sie, und es klingt nicht nach PR.")
    ui.talk("Martell", "Die 3.200 VC an Herrn Daal waren freigegeben. Zweck: ‚Westkai-Erbe‘ – wir wollten die Glocke als Leihgabe ins Foyer holen und vorher sicher sein, dass wir über das richtige Stück reden. Das Museum hat abgelehnt. Das Projekt wurde am selben Tag eingestellt.")
    ui.talk("Wynn", "Wer hat es geleitet?")
    ui.talk("Martell", "Elise Vardon. Nach der Absage hat sie es nicht mehr erwähnt. Ich hätte gedacht, das ist ein gutes Zeichen.")
    ui.say("Am Nachmittag liefert die Bank, was der Beschluss für Vardons Privatkonto hergibt. Eine Buchung reicht.")
    fakt(ui, Z, "cairn_projekt", "Cairn-Compliance: Der Daal-Auftrag war für das Ausstellungsprojekt „Westkai-Erbe“ freigegeben (Leihgabe ins Foyer); nach der Absage des Museums wurde das Projekt eingestellt. Projektleitung: Elise Vardon.")
    fakt(ui, Z, "anzahlung", "Vardons Privatkonto: 5.000 VC an Marek Dane, Verwendungszweck „Anzahlung Privaterwerb B-17“, vier Tage vor dem Diebstahl.")
    aussage(ui, Z, "revik_leihe", "Sanna Revik bestätigt: Cairn bat vor drei Wochen um eine Dauerleihgabe der Glocke; sie lehnte ab.")
    setf(Z, "vardon_anzahlung")
    ui.talk("Wynn", "Ein Museum, das nicht verkauft. Und vier Tage vor dem Einbruch zahlt jemand eine Anzahlung für genau dieses Stück. Für einen Erwerb, den es legal nicht geben konnte.")
    if not hat(Z, "ev_id"):
        frage(ui, Z, "ev", "teilweise", "Vardon zahlte Dane eine Anzahlung für B-17 – sie ist die naheliegende „E. V.“, belegt ist das noch nicht.")
    frage(ui, Z, "cairn", "teilweise", "Der Konzern verfolgte ein legitimes Ausstellungsprojekt; Vardon leistete privat eine Anzahlung vor dem Diebstahl – ob sie von einem Diebstahl wusste, ist offen.")
    frage(ui, Z, "dane", "teilweise", "Dane nahm vier Tage vor dem Diebstahl eine Anzahlung für „Privaterwerb B-17“ an – für ein Stück, das niemand verkaufte.")


def k2_storno(ui, Z):
    ui.title("Funkzellen")
    ui.ort("Präsidium · IT-Forensik")
    ui.say("Die Analystin heißt Bea Yilmaz und isst seit zwei Stunden dasselbe Brötchen. Auf ihrem Bildschirm: die Prepaid-Nummer des Stornoanrufs.")
    ui.talk("Yilmaz", "Aktiviert am Tag nach dem Diebstahl, 15:58 Uhr, Kiosk am Ankerplatz. Zwei Straßen von der Cairn-Zentrale. Bar bezahlt. Und jetzt kommt’s.")
    ui.say("Sie zieht ein zweites Fenster daneben: den Chat auf Danes Telefon. Dieselbe Nummer. ‚Ich habe dem Transport zugestimmt, nicht dem Diebstahl.‘")
    ui.say("Der Kioskbetreiber erkennt die Käuferin bei einer Wahllichtbildvorlage ohne Zögern: Elise Vardon. Am Abend wird sie zur Vernehmung geladen; ihr Telefon wird per Beschluss sichergestellt. Darin steckt eine zweite SIM-Karte.")
    fakt(ui, Z, "storno_nummer", "Die Prepaid-Nummer des Stornoanrufs ist identisch mit der Nummer des Chat-Gegenübers auf Danes Telefon; aktiviert am Tag nach dem Diebstahl um 15:58 Uhr an einem Kiosk am Ankerplatz.")
    aussage(ui, Z, "kiosk", "Kioskbetreiber: erkennt bei einer Wahllichtbildvorlage Elise Vardon als Käuferin der SIM-Karte.")
    fakt(ui, Z, "vardon_sim", "In Vardons sichergestelltem Telefon steckt die SIM-Karte dieser Prepaid-Nummer.")
    setf(Z, "nummer_id", "ev_id")
    if hat(Z, "dane_rusk_behauptung"):
        fakt(ui, Z, "dane_luege", "Danes Aussage, das Chat-Gegenüber sei der Fahrer Rusk gewesen, ist widerlegt.")
    frage(ui, Z, "ev", "geklärt", "„E. V.“ ist Elise Vardon; ihr gehört die Prepaid-Nummer aus Chat und Stornoanruf.")
    frage(ui, Z, "cairn", "teilweise", "Eine Cairn-Führungskraft handelte nach dem Diebstahl privat – ob sie vorher von einer illegalen Beschaffung wusste, ist offen.")


def k2_tischler(ui, Z):
    ui.title("Tischlerei Brandt")
    ui.ort("Kanalviertel")
    ui.say("Die Holzhalterung aus Lagerplatz N-14 trägt auf der Unterseite ein eingebranntes Zeichen: ‚BR‘. Es gibt in Vesper genau eine Tischlerei, die noch so signiert. Ole Brandt holt sein Auftragsbuch, bevor Wynn fragt.")
    ui.talk("Brandt", "Halterung für eine Glocke, Durchmesser 58 Zentimeter, 140 Kilo. Die Maße hat mir der Kunde als Kopie gebracht – hier, aus einem Katalog. Bestellt hat ‚M. Dane‘. Bar bezahlt.")
    ui.say("Die Kopie im Auftragsbuch zeigt Seite 17 des Bestandsverzeichnisses von 1991. Eintrag B-17. Das Bestelldatum liegt fünf Tage vor dem Diebstahl.")
    ui.talk("Brandt", "Er hatte es eilig. Sagte, das Stück komme ‚nachts‘ und die Halterung müsse bis Montag fertig sein. Ich dachte an einen Nachttransport. Wer denkt denn an so was.")
    fakt(ui, Z, "tischler", "Tischlerei Brandt: Die Halterung wurde von „M. Dane“ fünf Tage vor dem Diebstahl bestellt (Maße laut Kopie von Katalogeintrag B-17), einen Tag vor dem Diebstahl abgeholt, bar bezahlt.")
    aussage(ui, Z, "brandt", "Ole Brandt: Dane sagte, das Stück komme „nachts“; die Halterung müsse bis Montag fertig sein.")
    setf(Z, "tischler")
    frage(ui, Z, "dane", "teilweise", "Dane bereitete die Aufnahme der Glocke vor dem Diebstahl vor – dass er den Einbruch kannte, ist damit noch nicht bewiesen.")


def k2_daal(ui, Z):
    kapitel1.lead_daal(ui, Z, tag=True)


LEADS = {
    "einbruch": ("Die Einbruchsspuren im Museum mit Sanna Revik durchgehen", k2_einbruch),
    "rusk": ("Kellan Rusk erneut vernehmen lassen – von wem bekam er die Kiste?", k2_rusk),
    "quist": ("Nella Quist zu den Vermittlern im Hintergrund befragen lassen", k2_quist),
    "cairn": ("Cairn von innen prüfen – Zahlungswege hinter dem Identifizierungsauftrag", k2_cairn),
    "storno": ("Den Stornoanruf zurückverfolgen – wer kannte den Buchungscode?", k2_storno),
    "tischler": ("Die Holzhalterung zurückverfolgen – wer hat sie gebaut, und wann?", k2_tischler),
    "daal": ("Corvin Daal zur Depot-Aufnahme befragen lassen", k2_daal),
}


def pool(Z):
    p = ["einbruch", "rusk", "quist", "cairn", "tischler"]
    if Z["fragen"]["depot"][0] != "geklärt":
        p.append("daal")
    if Z["tier"] == "C":
        p.append("storno")
    return [k for k in p if k not in Z["k2_done"]]


def lagebesprechung(ui, Z):
    while len(Z["k2_done"]) < 3:
        ui.title("Lagebesprechung")
        rest = 3 - len(Z["k2_done"])
        ui.ort(f"Präsidium · noch {rest} Ermittlungsschritt{'e' if rest > 1 else ''} bis zur Abendbesprechung")
        if rest == 2:
            ui.talk("Wynn", "Die Spurensicherung im Museum arbeitet ohnehin. Ich habe Leute für zwei weitere Spuren heute. Was zuerst?")
        else:
            ui.talk("Wynn", "Eine Spur schaffen wir noch, bevor das Labor liefert. Welche?")
        avail = pool(Z)
        k = avail[ui.choose([LEADS[x][0] for x in avail], Z, save=True)]
        LEADS[k][1](ui, Z)
        Z["k2_done"].append(k)
        ui.pause()


# ───────────────────────────── Zugriff ─────────────────────────────

def zugriff(ui, Z):
    ui.title("Die Wandleserin")
    ui.ort("17:30 Uhr · Präsidium")
    if "handschuh_fund" not in Z["fakten"]:
        ui.say("Die Spurensicherung im Museum hat ihre Arbeit beendet. Im Abflussgitter des Wirtschaftsgangs lag ein Arbeitshandschuh, grau von Mörtelstaub.")
        fakt(ui, Z, "handschuh_fund", "Arbeitshandschuh mit Mörtelstaub im Abflussgitter des Wirtschaftsgangs sichergestellt.")
    ui.say("Das Labor liefert am späten Nachmittag. Wynn liest es zweimal.")
    fakt(ui, Z, "dna_kess", "DNA am Arbeitshandschuh aus dem Museum: Treffer Vera Kess (Faultline) – in der Datenbank wegen einer früheren Sachbeschädigung.")
    fakt(ui, Z, "maelzerei", "Kess' Telefon war die letzten zwei Nächte im Kanalviertel eingeloggt; eine Streife meldet Licht in der stillgelegten Mälzerei an der Kanalstraße.")
    setf(Z, "kess_id")
    frage(ui, Z, "org", "teilweise", "Vera Kess ist am Tatort nachgewiesen (DNA). Wer sie beauftragt hat, ist offen.")
    ui.talk("Wynn", "Ich habe einen Haftbefehl gegen Vera Kess. Und ich habe ein Gebäude, das älter ist als dieses Präsidium – mit einer Frau darin, die Wände reißen lassen kann, wo sie schon schwach sind. Davon hat die Mälzerei reichlich.")
    if hat(Z, "sen_spur"):
        ui.talk("Wynn", "Und vermutlich jemanden, der das Licht schluckt. Samir Sen – die Signatur passt, und Kess und Sen wurden im Frühjahr gemeinsam kontrolliert.")
        fakt(ui, Z, "kontrolle", "Polizeiliche Kontrolle im Frühjahr: Vera Kess und Samir Sen (Gloam) gemeinsam angetroffen.")
        setf(Z, "sen_bekannt")
    else:
        ui.talk("Wynn", "Ob sie allein ist, weiß ich nicht. Das macht mir mehr Sorgen als die Wände.")
    opts = ["[GEFAHR] Sofortiger Zugriff in der Mälzerei – die Unit sichert Statik, Licht und Rettung",
            "Observation – Festnahme, sobald Kess das Gebäude verlässt (kein Einsatzrisiko, aber langsamer)"]
    keys = ["sturm", "observation"]
    if hat(Z, "kess_reue"):
        opts.append("Über Kess' Anwältin ein Kronzeugen-Angebot vorlegen – sie hat den Wachmann gewarnt")
        keys.append("kronzeugin")
    k = keys[ui.choose(opts, Z)]
    {"sturm": sturm, "observation": observation, "kronzeugin": kronzeugin}[k](ui, Z)
    if not hat(Z, "serrat_name"):
        ui.talk("Wynn", "TRH. Das Kürzel kenne ich. Moment.")
        ui.say("Er zieht eine alte Akte aus dem Archivsystem: ein eingestelltes Verfahren gegen Leute aus dem Umfeld der Seitenlinie, zwei Jahre alt.")
        fakt(ui, Z, "altakte", "Eingestelltes Verfahren vor zwei Jahren: „TRH“ taucht dort als Abrechnungskürzel von Ivo Serrat (Misrule) auf.")
        setf(Z, "serrat_name")
    frage(ui, Z, "org", "teilweise", "Ausgeführt von Vera Kess" + (" und Samir Sen" if hat(Z, "sen_id", "sen_bekannt") else "")
          + "; Auftraggeber laut Spurenlage der „Treuhänder“ – Ivo Serrat steht im Verdacht.")
    ui.pause()


def sturm(ui, Z):
    ui.ort("19:00 Uhr · Alte Mälzerei, Kanalstraße")
    ui.talk("Wynn", "Ich frage die Unit konkret an: Sichert das Gebäude, damit meine Leute festnehmen können, ohne dass ihnen die Decke auf den Kopf fällt. Festnahme und Beweise machen wir.")
    sel, opfer, cov = gefahr_mission(ui, Z, "Mälzerei", ROLLEN_MAELZEREI, MAELZEREI_ZEILE, MAELZEREI_TOD,
                                     extra=0.0 if hat(Z, "sen_bekannt") else 0.10)
    ui.say("Im Darrboden steht Vera Kess, die Hände an einer Säule. Als die Beamten rufen, zieht ein Riss durch den Boden – nicht auf die Beamten zu, sondern von ihnen weg, zur Hintertür. Sie will raus, nicht kämpfen.")
    if any(m in sel for m in ROLLEN_MAELZEREI["Licht"]):
        ui.say("Das Licht sinkt auf ein Glimmen – und kommt zurück. Irgendwo im Treppenhaus flucht ein Mann.")
    else:
        ui.say("Das Licht sinkt auf ein Glimmen und bleibt dort. Die Beamten arbeiten mit Taschenlampen, die kaum weiter als einen Meter reichen.")
    if "Nico" in sel:
        ui.say("Samir Sen erreicht die Hintertür und landet auf Nicos Rampe so elegant wie ein Sack Kartoffeln. Zwei Beamte nehmen ihn in Empfang.")
    else:
        ui.say("Samir Sen erreicht die Hintertür und läuft dort zwei Beamten in die Arme, die im Dunkeln auf ihn gewartet haben.")
    if opfer:
        ui.say("Vera Kess sitzt auf dem Boden des Darrbodens, die Hände voller Staub, und starrt auf das, was sie losgetreten hat. ‚Ich wollte nur raus‘, sagt sie. ‚Ich wollte nie, dass …‘ Sie spricht den Satz nicht zu Ende.")
        ui.say("In der Nacht verlangt sie nach Wynn. Sie nennt einen Namen.")
        aussage(ui, Z, "kess_aussage", "Vera Kess (nach dem Einsturz, ohne Absprache): Den Einbruch habe Ivo Serrat organisiert, der „Treuhänder“; sie habe die Wand geöffnet, Samir Sen das Licht gedämpft.")
        setf(Z, "kess_aussage", "serrat_name")
    else:
        ui.say("Vera Kess lässt sich ohne weiteren Widerstand festnehmen. Sie sagt nur einen Satz: ‚Ich rede mit meiner Anwältin.‘")
    fakt(ui, Z, "festnahme_kess", "Vera Kess wurde in der Mälzerei an der Kanalstraße festgenommen.")
    fakt(ui, Z, "festnahme_sen", "Samir Sen (Gloam) wurde beim Fluchtversuch aus der Mälzerei festgenommen.")
    fakt(ui, Z, "sen_telefon", "Auf Samir Sens Telefon: Nachricht vom Kontakt „TRH-7“, drei Tage vor dem Diebstahl – „Zollhof C, Dienstag 02:00. Wand hinten links, alte Naht. Zahlung nach Übergabe.“")
    setf(Z, "festnahme_kess", "festnahme_sen", "sen_telefon", "trh_kanal", "trh7", "sen_id")


def observation(ui, Z):
    ui.ort("Nacht · Zivilwagen an der Kanalstraße")
    ui.say("Die Nacht vergeht in einem Zivilwagen, der nach kaltem Kaffee riecht. Um 06:10 Uhr verlässt Vera Kess die Mälzerei mit einem Rucksack und geht zur Straßenbahnhaltestelle. Zwei Beamte nehmen sie fest, bevor die Bahn kommt. Sie wehrt sich nicht.")
    fakt(ui, Z, "festnahme_kess", "Vera Kess wurde an der Haltestelle Kanalstraße festgenommen.")
    fakt(ui, Z, "kess_telefon", "Auf Kess' Telefon: Nachricht vom Kontakt „TRH-7“, drei Tage vor dem Diebstahl – „Zollhof C, Dienstag 02:00. Wand hinten links, alte Naht. Zahlung nach Übergabe.“")
    setf(Z, "festnahme_kess", "kess_telefon", "trh_kanal", "trh7")
    if hat(Z, "sen_bekannt"):
        ui.say("Weil Wynn wusste, nach wem er sucht, stand auch am Kanalsteg ein Wagen. Samir Sen kommt zwanzig Minuten später – und geht in Handschellen wieder.")
        fakt(ui, Z, "festnahme_sen", "Samir Sen (Gloam) wurde am Kanalsteg hinter der Mälzerei festgenommen.")
        setf(Z, "festnahme_sen", "sen_id")
    else:
        ui.say("Was niemand wusste: Kess war nicht allein. Gegen 06:30 Uhr verlässt ein dünner Mann die Mälzerei über den Kanalsteg. Bis jemand begreift, wer er ist, ist er weg.")
        fakt(ui, Z, "sen_id", "Kess' Telefon: Der Kontakt „S.“ ist Samir Sen (Gloam) – zur Fahndung ausgeschrieben.")
        setf(Z, "sen_flucht", "serrat_gewarnt", "sen_id")
        ui.note("warn", "Samir Sen ist flüchtig. Wer auch immer hinter TRH-7 steht, dürfte jetzt gewarnt sein.")
    ui.say("Vera Kess sagt im Präsidium nur einen Satz: ‚Ich rede mit meiner Anwältin.‘")


def kronzeugin(ui, Z):
    ui.ort("20:15 Uhr · Telefonat mit Kess' Anwältin")
    ui.say("Wynn ruft Pia Lorenz an, die Anwältin, die Kess vor zwei Jahren vertreten hat. Er sagt nicht viel: dass ihre Mandantin einen Wachmann gewarnt hat, bevor die Wand fiel. Dass er das sieht. Dass die Staatsanwaltschaft es auch sehen kann – wenn Kess heute noch redet.")
    ui.say("Um 22:40 Uhr kommt Vera Kess ins Präsidium, die Anwältin neben sich, die Hände in den Ärmeln ihres Pullovers.")
    ui.talk("Kess", "Ivo Serrat. Er nennt sich Treuhänder. Er hat mir die Wand gezeigt – auf einem Bauplan von 1954, den er aus dem Stadtarchiv hatte. Samir hat das Licht gemacht, ich die Wand. Die Glocke haben wir zu zweit auf den Rollwagen gehoben, dann Zollhof C.")
    ui.talk("Kess", "Die Naht ist breiter gerissen, als sie sollte. Ich habe ‚Zurück!‘ gerufen. Ich hab gesehen, wie er fällt. Serrat hat am Telefon gesagt: ‚Kein Anruf, sonst sind wir alle dran.‘ Ich hab gehorcht. Das ist das, was ich nicht loswerde.")
    ui.say("Sie schiebt ihr Telefon über den Tisch.")
    aussage(ui, Z, "kess_aussage", "Vera Kess (Kronzeugin): Ivo Serrat („Treuhänder“) organisierte den Einbruch anhand eines Bauplans von 1954 aus dem Stadtarchiv; sie öffnete die Wand, Samir Sen dämpfte das Licht; Serrat untersagte einen Notruf für den verletzten Wachmann.")
    fakt(ui, Z, "kess_telefon", "Auf Kess' Telefon: Nachricht vom Kontakt „TRH-7“, drei Tage vor dem Diebstahl – „Zollhof C, Dienstag 02:00. Wand hinten links, alte Naht. Zahlung nach Übergabe.“")
    ui.say("Am nächsten Morgen prüft Wynn die Angabe zum Bauplan.")
    fakt(ui, Z, "archiv_bauplan", "Stadtarchiv: Der Bauplan des Museums-Wirtschaftsgangs von 1954 wurde sechs Wochen vor dem Diebstahl eingesehen – die hinterlegte Ausweiskopie zeigt Ivo Serrat.")
    setf(Z, "kess_aussage", "kess_telefon", "kronzeugin", "trh_kanal", "trh7", "serrat_name", "festnahme_kess", "archiv_bauplan", "sen_id")
    fakt(ui, Z, "festnahme_kess", "Vera Kess stellte sich mit ihrer Anwältin und wurde festgenommen; die Staatsanwaltschaft prüft die Kronzeugenregelung.")
    if hat(Z, "sen_bekannt"):
        ui.say("Kess nennt die Mälzerei. Weil Wynn den Ort ohnehin beobachten ließ, ist Samir Sen eine Stunde später in Gewahrsam.")
        fakt(ui, Z, "festnahme_sen", "Samir Sen (Gloam) wurde in der Mälzerei an der Kanalstraße festgenommen.")
        setf(Z, "festnahme_sen")
    else:
        ui.say("Kess nennt die Mälzerei und einen Namen: Samir Sen. Als die Streife dort ankommt, ist nur noch ein warmer Teekessel übrig.")
        setf(Z, "sen_flucht", "serrat_gewarnt")
        ui.note("warn", "Samir Sen ist flüchtig. Serrat dürfte jetzt gewarnt sein.")


# ───────────────────────────── Bilanz ─────────────────────────────

WEGE = {
    "durchsuchung": "Haftbefehl gegen Ivo Serrat beantragen und seine Geschäftsräume in der Börsengasse durchsuchen lassen",
    "falle": "[GEFAHR] Serrat über den Kanal TRH-7 mit einem fingierten Folgeauftrag an den Westkai locken – die Unit sichert die Übergabe",
    "vardon": "Elise Vardon mit allem vernehmen lassen, was vorliegt – erst die Käuferseite schließen",
    "dane": "Der Staatsanwaltschaft ein Gespräch mit Marek Dane vorschlagen – Aussage gegen Strafmilderung",
}


def wege(Z):
    w = ["durchsuchung"]
    if hat(Z, "trh_kanal"):
        w.append("falle")
    if hat(Z, "ev_id"):
        w.append("vardon")
    w.append("dane")
    return w


def bilanz(ui, Z):
    ui.title("Kapitelbilanz")
    tot = [TEAM[k] for k in Z["tot"]]
    ui.say(f"Beweise: {len(Z['fakten'])} · Aussagen: {len(Z['aussagen'])} · Fragen geklärt: "
           f"{sum(1 for v in Z['fragen'].values() if v[0] == 'geklärt')} von 6")
    if tot:
        ui.note("warn", "Gefallen: " + ", ".join(tot))
    ui.talk("Wynn", "Ich will Serrat. Aber ich will ihn mit etwas, das vor Gericht hält – nicht mit einer Signatur und einem Gerücht. Wie gehen wir es an?")
    w = wege(Z)
    Z["k3_weg"] = w[ui.choose([WEGE[x] for x in w], Z, save=True)]


def spielen(ui, Z):
    if Z["phase"] == "start":
        auftakt(ui, Z)
        k = Z["folge"] or "einbruch"
        LEADS[k][1](ui, Z)
        Z["k2_done"].append(k)
        ui.pause()
        Z["phase"] = "hub"
    if Z["phase"] == "hub":
        lagebesprechung(ui, Z)
        Z["phase"] = "zugriff"
    if Z["phase"] == "zugriff":
        zugriff(ui, Z)
        Z["phase"] = "bilanz"
    if Z["phase"] == "bilanz":
        bilanz(ui, Z)
        Z["kapitel"], Z["phase"] = 3, "start"
