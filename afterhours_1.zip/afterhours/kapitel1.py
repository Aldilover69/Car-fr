# -*- coding: utf-8 -*-
"""AFTERHOURS – Kapitel 1: Die Reservierung."""
from engine import (TEAM, FRAGEN, L, aussage, fakt, frage, gefahr_mission, hat,
                    setf, auswahl, lebend)

ROLLEN_MORGEN = {"Fluchtwege": ["Nico", "Mara"], "Schutz": ["Daniel", "Leila"],
                 "Überblick": ["Juno", "Asha", "Imani"]}
ROLLEN_HALLE = {"Statik": ["Mara", "Daniel", "Asha"], "Wasser/Strom": ["Imani", "Nico"],
                "Rettung": ["Leila", "Juno"]}

MORGEN_ZEILE = {
    "Daniel": "Daniel steht am Hallentor, den Schock eines möglichen Rammversuchs schon im Körper gespeichert.",
    "Mara": "Mara verankert das Rolltor in offener Position – niemand kann sich einsperren oder aussperren.",
    "Nico": "Nico macht die Zufahrt für jedes Fluchtfahrzeug zur Rutschbahn.",
    "Asha": "Asha dämpft das Dröhnen des Tors und hört im Hof einen zweiten Motor anspringen.",
    "Imani": "Imani hält den Torantrieb unter Kontrolle, damit niemand die Halle von innen versiegeln kann.",
    "Leila": "Leila wartet hinter den Fahrzeugen, die Hände frei für jeden, der im Weg steht.",
    "Juno": "Juno liegt auf dem Dach der Gießerei und überblickt Hof und Zufahrt.",
}
HALLE_ZEILE = {
    "Daniel": "Daniel nimmt den herabrieselnden Putz als kinetische Last auf – Stück für Stück.",
    "Mara": "Mara verankert den Mittelträger der Zwischendecke an seiner jetzigen Position.",
    "Nico": "Nico macht die Kellertreppe griffig, wo das Wasser sie in eine Rutschbahn verwandelt hat.",
    "Asha": "Asha fokussiert den Schall und hört das Gebälk knacken, bevor es sichtbar wird.",
    "Imani": "Imani unterbricht den uralten Verteiler, bevor Wasser und Strom zueinanderfinden.",
    "Leila": "Leila bleibt dicht hinter dem Trupp, bereit, jeden zu stabilisieren.",
    "Juno": "Juno prüft von oben die Fluchtwege der Galerie, Tritt für Tritt.",
}
HALLE_TOD = {
    "Daniel": "Daniel fängt die Last der stürzenden Decke auf – mehr, als er speichern kann.",
    "Mara": "Mara hält den Träger einen Atemzug länger, als sie sollte. Dann gibt der Boden unter ihr nach.",
    "Nico": "Nico rutscht im Wasser der Kellertreppe in die Dunkelheit. Halt gibt es dort keinen mehr.",
    "Asha": "Asha hört das Geräusch als Erste. Sie schafft es noch, die anderen zu warnen – sich selbst nicht.",
    "Imani": "Der Verteiler bricht durch, als Imani noch an der Leitung ist.",
    "Leila": "Leila hält einen Kollegen am Leben, bis die Decke fällt – und bleibt bei ihm.",
    "Juno": "Juno springt. Die Trittfläche trägt, die Landung nicht.",
}


def uhr(Z):
    return f"{Z['uhr'] // 60 % 24:02d}:{Z['uhr'] % 60:02d}"


def ident(Z):
    return "mietvertrag" in Z["fakten"] or "halle" in Z["fakten"]


def ev_geklaert(ui, Z):
    setf(Z, "ev_id")
    frage(ui, Z, "ev", "teilweise" if not hat(Z, "nummer_id") else "geklärt",
          "„E. V.“ ist Elise Vardon (Cairn Maritime Holdings), Mieterin des Zielorts. Wem die unbekannte Chat-Nummer gehört, ist noch offen."
          if not hat(Z, "nummer_id") else
          "„E. V.“ ist Elise Vardon; die Chat-Nummer gehört ebenfalls ihr.")
    if "daal" in Z["aussagen"]:
        frage(ui, Z, "cairn", "teilweise", "Vardon beauftragte die Identifizierung persönlich und mietete später das Zielobjekt – Mitwissen vor dem Diebstahl ist nicht belegt.")
    else:
        frage(ui, Z, "cairn", "teilweise", "Eine Cairn-Führungskraft handelte nach dem Diebstahl privat – Mitwissen vorher nicht belegt.")


# ───────────────────────────── Szenen ─────────────────────────────

def intro(ui, Z):
    ui.title("Vesper City")
    ui.say("Du bist Daniel Mercer, genannt Recoil, 38, ehemaliger Eliteheld und Leiter der Mercer Unit – ein Team, das in der inoffiziellen Rangliste der Stadt irgendwo um Platz 38 von 40 herumdümpelt und trotzdem Dinge erledigt.")
    ui.say("Bisher: Die gestohlene Hafenglocke ist wieder da. Kellan Rusk hatte sie in einer Transportkiste, Marek Dane lief am Tor 4 der Polizei in die Arme, und bei Harborlight Storage passte eine Holzhalterung exakt zur Kiste. Was fehlt, ist der Mensch am Ende der Kette.")
    ui.note("info", "Die Polizei führt den Fall. Die Mercer Unit hilft nur, wenn Detective Wynn sie konkret anfragt. In der Fallakte stehen Beweise, Aussagen und offene Fragen getrennt.")
    ui.pause()


def praesidium(ui, Z):
    ui.kapitel_karte(1, "Die Reservierung", "Wer wartet am Ende der Transportkette?")
    ui.ort("Präsidium Vesper · 22:15 Uhr")
    ui.say("Hinter der Glasscheibe sitzt Marek Dane, die Hände flach auf dem Tisch, neben ihm eine Anwältin, die seit vierzig Minuten kein Wort gesagt hat. Im Besprechungsraum nebenan breitet Detective Tarek Wynn Dispositionsprotokolle von Kaiweg Transport aus – freigegeben per Beschluss.")
    ui.talk("Wynn", "Buchung 4471. Angelegt über Morrows Konto am Tag nach dem Diebstahl, 08:12 Uhr – rund anderthalb Stunden, nachdem das Museum den Einbruch gemeldet hat. Abholung morgen früh um 07:30 Uhr bei Harborlight, Lagerplatz N-14. Ziel: Weidenhof 7 am Nordring, ein Privatlager. Empfänger: ‚E. V.‘.")
    ui.talk("Wynn", "Die Kisten aus N-14 liegen in der Asservatenkammer. Morgen früh stünde ein Transporter vor einem leeren Lagerplatz – oder ich lasse ihn fahren, mit einer Kiste, die nur so tut, als wäre sie schwer. Kontrollierte Lieferung. Das funktioniert aber nur, wenn ich weiß, wer am Zielort wartet.")
    ui.talk("Wynn", "Ich habe Personal für drei Maßnahmen bis zum Morgengrauen. Die Entscheidungen treffe ich – aber ich frage dich, was du priorisieren würdest. Die Unit bleibt in Bereitschaft; wenn ich sie brauche, frage ich konkret an. Übrigens: Das Gebäudeamt führt Weidenhof 7 als baufällig, Obergeschoss gesperrt.")
    fakt(ui, Z, "buchung", "Buchung 4471 (Kaiweg Transport): angelegt 08:12 Uhr am Tag nach dem Diebstahl, ca. 90 Minuten nach der Museumsmeldung; Abholung 07:30 Uhr, Harborlight N-14 nach Weidenhof 7 (Nordring); Empfänger „E. V.“.")
    fakt(ui, Z, "amt", "Weidenhof 7 (alte Eisengießerei) gilt beim Gebäudeamt als baufällig; Obergeschoss gesperrt.")
    ui.pause()


LEADS = {
    "mietvertrag": "Den Mietvertrag für Weidenhof 7 prüfen – Hausverwaltung und Grundbuch (Nachtbereitschaft)",
    "morrow": "Elias Morrow erneut vernehmen – Wynn hält ihm den Buchungszeitpunkt vor",
    "daal": "Corvin Daal vorladen und die Depot-Aufnahme mit ihm abgleichen",
    "halle": "[GEFAHR] Weidenhof 7 noch in der Nacht begehen – die Unit soll die baufällige Halle sichern",
    "dane": "Marek Dane vernehmen – gezielt mit dem Material, das bis dahin vorliegt",
}
ORDER = ["mietvertrag", "morrow", "daal", "halle", "dane"]


def lead_mietvertrag(ui, Z):
    ui.title("Weidenhof 7")
    ui.ort(f"{uhr(Z)} Uhr · Hausverwaltung, Nordring")
    ui.say("Das Grundbuchamt hat Nachtbereitschaft, die Hausverwaltung nicht – bis eine Streife den Verwalter Jens Holm aus dem Bett holt. Er erscheint im Anorak über dem Schlafanzug, einen Ordner unter dem Arm, der älter aussieht als er selbst.")
    ui.talk("Holm", "Weidenhof 7, alte Eisengießerei. Erdgeschosshalle vermietet, Obergeschoss gesperrt, das Gutachten hängt am Tor. Neue Mieterin seit dem Tag nach dem Einbruch im Museum – unterschrieben um 16:40 Uhr, sechs Monate im Voraus bezahlt. Von einem Privatkonto.")
    ui.talk("Wynn", "Name?")
    ui.talk("Holm", "Elise Vardon. Privat, nicht über die Firma – aber ihre Visitenkarte steckt im Ordner: Cairn Maritime Holdings. Sie wollte Anlieferung früh am Morgen, ohne Besuchereintrag. Ich dachte: Sammlerin. Die sind eigen.")
    ui.talk("Holm", "Und falls Sie heute Nacht rein wollen: vergessen Sie es. Im Keller steht das Wasser, die Verteiler sind von 1980, und die Zwischendecke hält nur, weil sie es gewohnt ist.")
    fakt(ui, Z, "mietvertrag", "Mietvertrag Weidenhof 7: Mieterin Elise Vardon (privat; Visitenkarte Cairn Maritime Holdings), unterzeichnet am Tag nach dem Diebstahl um 16:40 Uhr, sechs Monate im Voraus vom Privatkonto bezahlt, Anlieferung „ohne Besuchereintrag“ gewünscht.")
    ev_geklaert(ui, Z)


def lead_morrow(ui, Z):
    ui.title("Vernehmungsraum 2")
    ui.ort(f"{uhr(Z)} Uhr · Elias Morrow")
    ui.say("Elias Morrow sitzt sehr gerade, den Mantel gefaltet auf dem Schoß, als wäre das hier ein Beratungstermin. Sein Anwalt flüstert ihm etwas zu; Morrow winkt ab.")
    ui.talk("Wynn", "Ihre Buchung 4471 wurde um 08:12 Uhr angelegt. Das Museum meldete den Einbruch um 06:40 Uhr. Das Radio berichtete um sieben.")
    ui.talk("Morrow", "Ich höre morgens kein Radio.")
    ui.talk("Wynn", "Sie fragen auch nicht, was in den Kisten ist.")
    ui.talk("Morrow", "Das ist mein Geschäftsmodell, Herr Detective.")
    if ident(Z):
        ui.talk("Wynn", "Weidenhof 7 ist an Elise Vardon vermietet, seit dem Tag nach dem Einbruch. Was hat Dane über ‚E. V.‘ gesagt?")
        ui.say("Morrows Lächeln verrutscht um einen Millimeter. Sein Anwalt sagt ‚Keine Aussage‘, Morrow sagt: ‚Schon gut.‘")
        ui.talk("Morrow", "Dane sprach von ‚der Käuferin‘. Sie wolle keine Namen in Papieren. Als ich gegen zehn von dem Einbruch hörte, dachte ich an die Glocke. Ich habe die Buchung nicht storniert – ich habe Dane angerufen. Er sagte: Verwechslung des Museums. Ich wollte ihm glauben. 2.400 VC Honorar machen das leicht.")
        aussage(ui, Z, "morrow", "Morrow (bei Vorhalt des Mietvertrags): Dane sprach von „der Käuferin“, die „keine Namen in Papieren“ wolle; nach der Meldung gegen 10 Uhr habe er an die Glocke gedacht, die Buchung aber nicht storniert – Dane nannte es „Verwechslung des Museums“. Honorar: 2.400 VC.")
        frage(ui, Z, "morrow", "teilweise", "Morrow hatte nach der Meldung zumindest einen Verdacht und buchte trotzdem – Kenntnis vor dem Diebstahl ist nicht belegt.")
    else:
        ui.talk("Morrow", "Die Anweisung kam von Herrn Dane, über seinen Vermittlungscode. 2.400 VC für die Abwicklung. ‚E. V.‘ war ein Kürzel in einem Auftragsfeld. Mehr weiß ich nicht.")
        ui.say("Der Anwalt beendet die Vernehmung. Wynn klappt die Mappe zu: ‚Er weiß mehr. Aber ohne Namen am Zielort hängt er sich nicht auf.‘")
        aussage(ui, Z, "morrow_basic", "Morrow (ohne konkreten Vorhalt): Auftrag kam von Dane über den Vermittlungscode, 2.400 VC; „E. V.“ nur ein Kürzel; Inhalt der Kiste nie geprüft.")


def lead_daal(ui, Z, tag=False):
    ui.title("Brückgasse")
    if tag:
        ui.ort("Nachmittag · Corvin Daal")
        ui.say("Corvin Daal kommt freiwillig, nachdem Wynn ihm am Telefon gesagt hat, dass es um das Straßenbahndepot geht. Er trägt einen Aktenordner wie einen Schild vor der Brust und setzt sich, ohne den Mantel auszuziehen.")
    else:
        ui.ort(f"{uhr(Z)} Uhr · Corvin Daal")
        ui.say("Eine Streife holt Corvin Daal aus seinem Antiquitätenladen, in dem noch Licht brennt. Er kommt im Mantel über dem Schlafanzug, hält einen Aktenordner wie einen Schild vor der Brust und sagt auf dem ganzen Weg ins Präsidium kein Wort.")
    ui.talk("Daal", "Ich habe nichts gestohlen. Ich identifiziere. Das ist ein legales Gewerbe, mit Rechnung und Umsatzsteuer.")
    ui.say("Wynn legt das unscharfe Standbild aus dem Straßenbahndepot neben die Kopie des Kassenjournals, das der Depotverein herausgegeben hat: ein Verkauf um 16:52 Uhr, Vereinschronik, bar bezahlt. Die Aufnahme trägt den Zeitstempel 16:51 Uhr.")
    ui.talk("Daal", "Das bin ich. Vier Tage vor dem Einbruch. Ich habe nach alten Hafenobjekten gefragt, nach dem Reparaturzeichen – drei Striche im Kreis. Weil ich dafür bezahlt wurde.")
    ui.talk("Wynn", "Von wem?")
    ui.talk("Daal", "Cairn. Genauer: von Elise Vardon, persönlich. Sie wollte wissen, ob das Zeichen unverwechselbar ist. Nach dem Einbruch rief sie noch einmal an: ‚gründlich vergleichen‘. Deshalb Quayline. Dane hat mich auf B-17 gebracht, ‚ein ernsthafter Interessent‘. Dass Vardon der Interessent war, habe ich mir gedacht. Von einem Diebstahl wusste ich nichts – sonst hätte ich nie eine Rechnung gestellt.")
    fakt(ui, Z, "depot", "Depot-Kassenjournal (Verkauf 16:52 Uhr) und Überwachungsaufnahme (16:51 Uhr) passen zusammen; Corvin Daal bestätigt, die Person im Depot zu sein.")
    aussage(ui, Z, "daal", "Daal: Der Cairn-Auftrag kam von Elise Vardon persönlich; sie fragte, ob das Zeichen „unverwechselbar“ sei, und bat nach dem Diebstahl um erneuten Vergleich (Quayline). Dane nannte einen „ernsthaften Interessenten“. Vom Diebstahl habe er nichts gewusst.")
    frage(ui, Z, "depot", "geklärt", "Corvin Daal, im Rahmen des Cairn-Identifizierungsauftrags – Kassenjournal und Aussage stützen das.")
    if hat(Z, "ev_id"):
        ev_geklaert(ui, Z)
    else:
        frage(ui, Z, "ev", "teilweise", "Verdacht: „E. V.“ könnte Elise Vardon sein – nicht belegt.")
        frage(ui, Z, "cairn", "teilweise", "Der Cairn-Auftrag stammt von Elise Vardon persönlich; ob sie „E. V.“ ist, ist ungeklärt.")


def lead_dane(ui, Z):
    ui.title("Vernehmungsraum 1")
    ui.ort(f"{uhr(Z)} Uhr · Marek Dane")
    a = Z["aussagen"]
    st = int(ident(Z)) + int("morrow" in a) + int("daal" in a)
    ui.say("Marek Dane hat sich gefangen. Das Jackett hängt über der Stuhllehne, die Krawatte sitzt wieder, und neben ihm blättert seine Anwältin in einem Notizblock, auf dem nichts steht.")
    ui.talk("Wynn", "‚Nach der Meldung darf sie nicht im Zollhof bleiben.‘ Das steht auf Ihrem Telefon. Nach der Meldung. Sie wussten also, dass die Glocke gestohlen war.")
    if st >= 2:
        ui.say("Wynn legt nacheinander auf den Tisch, was die Nacht gebracht hat. Danes Anwältin hört auf zu blättern.")
        ui.talk("Dane", "Gut. Ich sage es einmal, und Sie schreiben es auf. ‚E. V.‘ ist Elise Vardon. Sie wollte die Glocke – privat, nicht für Cairn. Ich sollte sie beschaffen. Beschaffen. Nicht stehlen.")
        ui.talk("Dane", "Der Auftrag kam von jemandem, den ich nur als ‚Treuhänder‘ kenne: Messenger, kein Gesicht, bezahlt über einen eigenen Vermittlungscode. Zuletzt schrieb er: ‚Objekt wird bereitgestellt.‘ Dass das ein Einbruch war, habe ich erst durch die Meldung begriffen.")
        ui.talk("Wynn", "Und trotzdem haben Sie weitergemacht.")
        ui.talk("Dane", "Ja. Der Fahrer wollte nach der Meldung aussteigen – das ist der Chat auf meinem Telefon. Ich habe ihn unter Druck gesetzt. Das war falsch, ich weiß.")
        aussage(ui, Z, "dane", "Dane: „E. V.“ ist die Käuferin Elise Vardon (privat); er sollte „beschaffen“; Auftrag kam von einem unbekannten „Treuhänder“ per Messenger („Objekt wird bereitgestellt“); vom Einbruch habe er erst durch die Meldung erfahren; das Chat-Gegenüber sei der Fahrer Rusk gewesen.")
        setf(Z, "treuhaender", "dane_rusk_behauptung")
        frage(ui, Z, "dane", "teilweise", "Dane räumt Mittäterschaft nach der Meldung ein und bestreitet Wissen vorher – unbelegt.")
        frage(ui, Z, "org", "teilweise", "Laut Dane stellte ein unbekannter „Treuhänder“ das Objekt bereit.")
    elif st == 1:
        ui.talk("Anwältin", "Mein Mandant bestätigt, B-17 an Herrn Daal weitergeleitet und eine Lagerung vermittelt zu haben. Von einem Diebstahl wusste er nichts. Weitere Angaben macht er nicht.")
        aussage(ui, Z, "dane0", "Dane (über seine Anwältin): bestätigt Weitergabe von B-17 und Vermittlung der Lagerung; bestreitet Kenntnis eines Diebstahls; nennt keine Namen.")
    else:
        ui.talk("Anwältin", "Mein Mandant äußert sich nicht zu Vorhalten ohne tragfähige Grundlage. Ich kündige Beschwerde an.")
        ui.say("Draußen auf dem Flur sagt Wynn leise: ‚Zu früh. Wir hatten zu wenig in der Hand.‘")


def lead_halle(ui, Z):
    ui.title("Weidenhof 7 – bei Nacht")
    ui.ort(f"{uhr(Z)} Uhr · Nordring")
    ui.say("Die Gießerei liegt im Regen. Die Feuerwehr hat einen Zettel ans Tor geklebt: Betreten verboten. Wynn steht davor, die Kapuze tief im Gesicht.")
    ui.talk("Wynn", "Wenn dort drin schon etwas für morgen vorbereitet ist, kann es bis 07:30 Uhr weg sein. Gefahr im Verzug – den Beschluss bekomme ich. Aber ich schicke keinen Beamten in diese Halle, bevor jemand Zwischendecke, Keller und Verteiler gesichert hat.")
    ui.talk("Wynn", "Ich frage dich konkret an: Kann die Mercer Unit die Halle sichern, damit die Spurensicherung gefahrlos hinein kann? Das ist kein Routineeinsatz. Es kann Tote geben. Auch bei euch.")
    ui.say(f"{L(Z)} kennt Zwischendecken und sagt es nicht laut.")
    if ui.choose(["[GEFAHR] Ja – die Mercer Unit sichert die Halle (ausgewählte Teammitglieder können sterben)",
                  "Nein – nicht ohne tragfähigen Plan; wir suchen einen anderen Weg"], Z) == 1:
        ui.talk("Wynn", "Verstanden. Dann bleibt die Halle zu, bis es hell ist.")
        return False
    sel, opfer, cov = gefahr_mission(ui, Z, "Weidenhof 7", ROLLEN_HALLE, HALLE_ZEILE, HALLE_TOD)
    if opfer:
        ui.say("Die Halle ist gesichert – zu einem Preis. Wynn sagt lange nichts. Dann geht die Spurensicherung hinein.")
    else:
        ui.say("Es hält. Zentimeter für Zentimeter, aber es hält. Wynn nickt, und die Spurensicherung geht hinein – ihr bleibt draußen.")
    fakt(ui, Z, "halle", "Weidenhof 7: Montagebock mit Gummipolster in Glockenform, Frachtschild „E. V. – Übergabe nach Prüfung“; daneben eine Mappe mit Kopie des Mietvertrags auf Elise Vardon (privat).")
    ev_geklaert(ui, Z)
    return None


FUNKT = {"mietvertrag": lead_mietvertrag, "morrow": lead_morrow, "daal": lead_daal,
         "halle": lead_halle, "dane": lead_dane}


def hub(ui, Z):
    while Z["slots"] > 0:
        ui.title("Lagebesprechung")
        ui.ort(f"{uhr(Z)} Uhr · noch {Z['slots']} Maßnahme(n) bis zur Lieferung um 07:30 Uhr")
        if Z["done"]:
            ui.talk("Wynn", "Was hat als Nächstes Vorrang?")
        else:
            ui.talk("Wynn", "Wer ‚E. V.‘ ist, entscheidet, ob ich morgen früh jemanden festnehmen kann – oder nur zusehe, wie eine Buchung storniert wird. Was hat Vorrang?")
        avail = [k for k in ORDER if k not in Z["done"] and (k != "dane" or Z["done"])]
        k = avail[ui.choose([LEADS[x] for x in avail], Z, save=True)]
        if FUNKT[k](ui, Z) is False:
            continue
        Z["done"].append(k)
        Z["slots"] -= 1
        Z["uhr"] += 120
        ui.pause()


def punkte(Z):
    f, a = Z["fakten"], Z["aussagen"]
    p = 0
    if "mietvertrag" in f:
        p += 2
    if "halle" in f:
        p += 1 if "mietvertrag" in f else 2
    return p + int("morrow" in a) + int("daal" in a) + int("dane" in a)


def morgen(ui, Z):
    ui.title("Kontrollierte Lieferung")
    Z["uhr"] = 5 * 60 + 40
    ui.ort("05:40 Uhr · Weidenhof 7, Nordring")
    ui.say("Grauer Morgen über dem Nordring. Die alte Eisengießerei steht schwarz gegen den Himmel, das Rolltor einen Spalt offen. Wynn hat einen Kaiweg-Transporter organisiert: am Steuer ein Beamter in Arbeitskleidung, auf der Ladefläche eine Kiste voller Sandsäcke.")
    ui.talk("Wynn", "Ich frage die Unit jetzt konkret an – drei Kräfte, drei Aufgaben: Fluchtwege an Tor und Zufahrt, Schutz für meine Leute, Überblick über Hof und Dach. Zugriff, Festnahme und Beweissicherung machen wir. Ihr sorgt dafür, dass dabei niemand zu Schaden kommt.")
    sel = auswahl(ui, Z, ROLLEN_MORGEN)
    for m in sel:
        ui.say(MORGEN_ZEILE[m])
    pts = punkte(Z)
    cov = {r: any(m in sel for m in ms) for r, ms in ROLLEN_MORGEN.items()}
    ui.pause()
    if pts >= 4:
        Z["tier"] = "A"
        ui.say("07:12 Uhr. Ein dunkler Wagen hält vor dem Tor. Elise Vardon steigt selbst aus – grauer Mantel, Handschuhe, in der Hand eine kleine Taschenlampe, als wolle sie ein Stück Geschichte begutachten. Der Transporter rollt rückwärts in die Halle. Sie wartet, bis die Kiste abgesetzt ist, tritt heran und hebt selbst den Deckel.")
        ui.say("Sandsäcke. Sie erstarrt nur eine Sekunde. Dann tritt Wynn aus dem Schatten der Regale.")
        ui.talk("Wynn", "Frau Vardon, Sie sind vorläufig festgenommen. Verdacht der Hehlerei.")
        ui.talk("Vardon", "Ich möchte meinen Anwalt. Und ich möchte, dass etwas protokolliert wird: Ich habe diese Glocke nicht stehlen lassen.")
        ui.talk("Wynn", "Ein Mietvertrag einen Tag nach der Meldung. Eine Cairn-Rechnung davor. Sie müssen mir erklären, wie sich das reimt.")
        ui.talk("Vardon", "Das werde ich. Nicht hier.")
        Z["ergebnis"] = "Zugriff: Elise Vardon vorläufig festgenommen"
        setf(Z, "ev_id")
        fakt(ui, Z, "festnahme", "Elise Vardon wurde am Zielort Weidenhof 7 vorläufig festgenommen (Verdacht der Hehlerei); ihr Telefon ist beschlagnahmt, die Auswertung angeordnet.")
        frage(ui, Z, "cairn", "teilweise", "Vardon ist in Gewahrsam; ob sie vor dem Diebstahl von der Beschaffung wusste, ist weiter offen.")
    elif pts >= 2:
        Z["tier"] = "B"
        ui.say("07:20 Uhr. Elise Vardon kommt selbst – und sie kommt nicht allein: Ihr Anwalt steigt aus dem Fond, ruhig, mit Aktentasche. Als Wynn sich zu erkennen gibt, hebt sie die Hände, bevor er fragt.")
        ui.talk("Vardon", "Ich begleite Sie freiwillig. Ich habe nichts zu verbergen – außer meiner Dummheit.")
        ui.say("Im Präsidium sagt sie drei Stunden lang aus. Für eine Festnahme reicht die Lage nicht; sie verlässt das Haus mit ihrem Anwalt und einer Vorladung.")
        setf(Z, "ev_id")
        aussage(ui, Z, "vardon", "Elise Vardon (freiwillig, Anwalt anwesend): Dane bot ihr die Glocke als Stück aus Privatbesitz an; die Museumsmeldung hielt sie für eine Verwechslung, was er bestätigte. Sie wollte nur einlagern, bis die Herkunft geklärt sei.")
        frage(ui, Z, "cairn", "teilweise", "Vardon bestreitet Mitwissen; ein Gegenbeweis fehlt noch.")
        Z["ergebnis"] = "Befragung: Vardon bestreitet Mitwissen, nicht festgenommen"
    else:
        Z["tier"] = "C"
        ui.say("06:51 Uhr. Der Disponent von Kaiweg Transport ruft Wynn an: Die Buchung 4471 sei soeben telefonisch storniert worden. Prepaid-Nummer, Funkzelle im Hafenbereich – der Anrufer nannte den Buchungscode korrekt.")
        ui.say("Am Weidenhof 7 passiert nichts mehr. Niemand kommt. Der Transporter steht im Leerlauf vor der Halle.")
        ui.talk("Wynn", "Wir sind einen Schritt zu spät. Aber den Code kannten nur Morrow, Dane und der Empfänger – oder jemand, dem einer von ihnen ihn gegeben hat.")
        fakt(ui, Z, "storno", "Buchung 4471 wurde um 06:51 Uhr telefonisch storniert (Prepaid-Nummer, Funkzelle Hafenbereich); der Anrufer nannte den Buchungscode korrekt.")
        Z["ergebnis"] = "Fehlstart: Buchung storniert, Empfänger nicht erschienen"
    if Z["tier"] in "AB":
        if not cov["Fluchtwege"]:
            ui.note("warn", "Vardons Fahrer setzt rückwärts aus der Zufahrt, rammt einen Poller und flüchtet zu Fuß. Die Beamten holen ihn nach dreihundert Metern ein – ein Kollege stürzt dabei schwer.")
            Z["log"].append("Zwischenfall: Fahrer flüchtig, ein Beamter verletzt (keine Fluchtwegsicherung)")
        if not cov["Schutz"]:
            ui.note("warn", "Beim Zugriff kippt ein Palettenregal. Ein Beamter wird eingeklemmt – Rippenbruch, er wird es überleben.")
            Z["log"].append("Zwischenfall: Beamter verletzt (kein Schutz)")
        if not cov["Überblick"]:
            ui.note("warn", "Ein zweiter Mann, den niemand im Fond gesehen hat, verlässt die Halle durch den Hinterhof – mit einem Datenträger.")
            Z["log"].append("Zwischenfall: Mann mit Datenträger entkommen (kein Überblick)")
    ui.pause()


WEITER = {
    "einbruch": "Die Einbruchsspuren im Museum mit Kuratorin Sanna Revik durchgehen – wer hat die Glocke herausgeholt?",
    "rusk": "Kellan Rusk erneut vernehmen lassen – von wem bekam er die Kiste?",
    "quist": "Nella Quist zu den Vermittlern im Hintergrund befragen lassen",
    "cairn": "Cairn von innen prüfen – Zahlungswege hinter dem Identifizierungsauftrag",
    "storno": "Den Stornoanruf zurückverfolgen – wer kannte den Buchungscode?",
}


def bilanz(ui, Z):
    ui.title("Kapitelbilanz")
    ui.note("info", Z["ergebnis"])
    ui.say(f"Beweise: {len(Z['fakten'])} · Aussagen: {len(Z['aussagen'])} · Offene Fragen geklärt: "
           f"{sum(1 for v in Z['fragen'].values() if v[0] == 'geklärt')} von {len(FRAGEN)}")
    for l in Z["log"]:
        ui.note("warn", l)
    ui.talk("Wynn", "Die Glocke ist zurück, die Käuferseite zeichnet sich ab. Was mir fehlt: wer die Wand im Museum aufgemacht hat. Rusk war der Fahrer, Dane der Vermittler – aber keiner von beiden hat einen Wachmann niedergeschlagen. Wo setzen wir an?")
    keys = ["einbruch", "rusk", "quist", "storno" if Z["tier"] == "C" else "cairn"]
    k = keys[ui.choose([WEITER[x] for x in keys], Z)]
    Z["folge"] = k


def spielen(ui, Z):
    if Z["phase"] == "start":
        intro(ui, Z)
        praesidium(ui, Z)
        Z["phase"] = "hub"
    if Z["phase"] == "hub":
        hub(ui, Z)
        Z["phase"] = "morgen"
    if Z["phase"] == "morgen":
        morgen(ui, Z)
        Z["phase"] = "bilanz"
    if Z["phase"] == "bilanz":
        bilanz(ui, Z)
        Z["kapitel"], Z["phase"] = 2, "start"
