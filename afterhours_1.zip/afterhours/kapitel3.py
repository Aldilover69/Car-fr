# -*- coding: utf-8 -*-
"""AFTERHOURS – Kapitel 3: Glockenschlag."""
from engine import (L, TEAM, aussage, fakt, frage, gefahr_mission, hat, setf)

ROLLEN_KAI = {"Halt an der Kante": ["Nico", "Mara"], "Schutz": ["Daniel", "Leila"],
              "Ortung": ["Asha", "Imani", "Juno"]}
KAI_ZEILE = {
    "Daniel": "Daniel steht im Schatten des Kranhauses, nah genug, um jeden Stoß abzufangen, der jemanden über die Kante treibt.",
    "Mara": "Mara verankert das Geländer am Steg an drei Stellen. Es hat seit Jahren nicht mehr so fest gesessen.",
    "Nico": "Nico gibt den nassen Planken Halt – wer hier ins Taumeln kommt, rutscht wenigstens nicht.",
    "Asha": "Asha dämpft den Regen auf dem Blechdach und hört jeden Schritt zwischen den Containern.",
    "Imani": "Imani hängt die Kaibeleuchtung an ihre Kontrolle. Ein Gedanke, und es wird hell.",
    "Leila": "Leila wartet im Rettungswagen hinter Speicher 8, die Tür offen.",
    "Juno": "Juno hockt auf dem Kranausleger, hoch über dem Becken.",
}
KAI_TOD = {
    "Daniel": "Daniel fängt den Beamten, der über die Kante kippt – und den Schwung, der ihn selbst mitnimmt.",
    "Mara": "Mara hält das Geländer fest, als der Steg darunter wegbricht. Das Geländer hält.",
    "Nico": "Nico greift nach dem stürzenden Beamten. Auf dem Weg ins Wasser gibt es nichts mehr, dem er Halt geben kann.",
    "Asha": "Asha hört Serrats Schritte zu spät hinter sich. Ein Taumeln, eine Kante, das schwarze Wasser.",
    "Imani": "Imani reißt die Beleuchtung hoch, als das Kabel unter ihren Fingern ins Wasser fällt.",
    "Leila": "Leila springt einem Bewusstlosen hinterher ins Becken. Sie bringt ihn bis zur Leiter.",
    "Juno": "Juno springt vom Kranausleger, um den Weg abzuschneiden. Die letzte Trittfläche trägt, die Landung nicht.",
}

ROLLEN_TERMINAL = {"Gangway": ["Nico", "Mara"], "Schutz": ["Daniel", "Leila", "Juno"],
                   "Ortung": ["Asha", "Imani"]}
TERMINAL_ZEILE = {
    "Daniel": "Daniel steht am Fuß der Gangway, wo dreihundert Menschen an ihm vorbei müssen.",
    "Mara": "Mara verankert die Gangway am Kai. Wackeln wird sie heute nicht.",
    "Nico": "Nico gibt den Stufen der Gangway Halt, Stufe für Stufe, und dem Bodenbelag im Wartebereich gleich mit.",
    "Asha": "Asha dämpft den Lärm der Durchsagen und filtert eine Stimme heraus: höflich, warm, nicht in Eile.",
    "Imani": "Imani übernimmt die Drehkreuze an der Sperre. Niemand geht durch, den sie nicht durchlässt.",
    "Leila": "Leila geht mit dem Strom der Passagiere, die Hände frei.",
    "Juno": "Juno sitzt auf dem Dach des Abfertigungsgebäudes und sieht jede Bewegung auf der Mole.",
}
TERMINAL_TOD = {
    "Daniel": "Als die Menge in Panik gerät, stellt sich Daniel zwischen sie und die Kante. Er fängt alles ab – zu viel.",
    "Mara": "Mara hält die Gangway, als Serrat die Menschen darauf taumeln lässt. Sie selbst stürzt.",
    "Nico": "Nico zieht ein Kind von der Kante. Er selbst rutscht dorthin, wo keine Reibung mehr hilft.",
    "Asha": "Asha stellt sich Serrat in den Weg. Für drei Sekunden weiß sie nicht, wo oben ist – und die Gangway ist schmal.",
    "Imani": "Imani steht im Wasser der Löschanlage, als die Leitung bricht.",
    "Leila": "Leila hält einen gestürzten Passagier am Leben, als die Menge über sie hinweggeht.",
    "Juno": "Juno springt vom Dach, um Serrat den Weg abzuschneiden. Die Trittfläche trägt, die Landung nicht.",
}


def staerke(Z):
    """Wie gut ist der Fall gegen Serrat belegt?"""
    gew = {"sprachnachricht": 1, "trh7": 1, "kess_aussage": 2, "sen_telefon": 1, "kess_telefon": 1,
           "ledger": 1, "ledger_full": 1, "dane_gestaendnis": 2, "serrat_handy": 2,
           "in_flagranti": 1, "archiv_bauplan": 1}
    return sum(v for k, v in gew.items() if hat(Z, k))


def staerke_text(Z):
    s = staerke(Z)
    return "stark" if s >= 6 else "solide" if s >= 4 else "dünn"


# ───────────────────────────── Wege ─────────────────────────────

def w_durchsuchung(ui, Z):
    ui.title("Börsengasse 14")
    ui.ort("Serrat Konsultationen")
    ui.say("Der Richter brauchte zwanzig Minuten für den Beschluss. Die Beamten brauchen keine zwei für die Tür.")
    if hat(Z, "serrat_gewarnt"):
        ui.say("Das Büro ist aufgeräumt wie ein Hotelzimmer am Abreisetag. Im Aktenvernichter: ein Korb voller Streifen. Die Spurensicherung braucht bis zum Nachmittag, um eine Seite davon zusammenzusetzen.")
        fakt(ui, Z, "ledger", "Rekonstruierte Seite aus Serrats Aktenvernichter: „TRH-7 · Westkai · M. D. · E. V. · 30 %“.")
        setf(Z, "ledger")
    else:
        ui.say("Serrat ist nicht da. Sein Büro schon – und ein ledergebundenes Kassenbuch in einer Schublade mit doppeltem Boden, handschriftlich, sorgfältig wie ein Buchhalter des vorigen Jahrhunderts.")
        fakt(ui, Z, "ledger", "Serrats Kassenbuch: „TRH-7 – Glocke Westkai – Anfrage M. D. (vor 19 Tagen) – Käuferin E. Vardon – Ausführung V. K. / S. S. – Zollhof C – Di. – M. D. informiert – 30 %“.")
        fakt(ui, Z, "ledger_bauplan", "In derselben Schublade: eine Kopie des Museumsbauplans von 1954, Wirtschaftsgang, eine Naht mit Bleistift markiert.")
        setf(Z, "ledger", "ledger_full", "dane_wusste", "ev_id", "archiv_bauplan")
        ui.talk("Wynn", "‚M. D. informiert.‘ Mit Datum. Dane wusste, welche Nacht.")
    ui.say("Serrats Haushälterin sagt, er sei ‚auf Reisen‘. Kurz darauf meldet die Hafenpolizei: Ein I. Serrat hat für heute Abend, 20:00 Uhr, eine Kabine auf der Fähre nach Port Halden gebucht.")
    fakt(ui, Z, "faehre", "Ivo Serrat hat für 20:00 Uhr eine Kabine auf der Fähre nach Port Halden (Fährterminal Ostmole) gebucht.")
    setf(Z, "serrat_faehre", "serrat_name")


def w_vardon(ui, Z):
    ui.title("Vernehmungsraum 1")
    ui.ort("Elise Vardon")
    ui.say("Elise Vardon sitzt aufrecht, die Hände um einen Pappbecher Tee, den sie nicht trinkt. Ihr Anwalt hat ihr geraten zu schweigen. Wynn legt trotzdem aus, was er hat, ein Blatt nach dem anderen.")
    if hat(Z, "nummer_id"):
        ui.talk("Wynn", "Ihre zweite SIM. Ihr Chat mit Marek Dane. ‚Wenn sie wirklich aus dem Museum stammt, ist das vorbei.‘ Und am nächsten Morgen stehen Sie trotzdem in der Halle.")
    if hat(Z, "vardon_anzahlung"):
        ui.talk("Wynn", "Fünftausend VC Anzahlung, vier Tage vor dem Einbruch. Für ein Stück, das kein Museum verkauft.")
    ui.say("Vardon schaut lange auf das Blatt mit dem Foto der Glocke. Dann schiebt sie den Becher weg.")
    ui.talk("Vardon", "Mein Großvater hat diese Glocke geläutet. Achtzehn Jahre lang, Schichtwechsel am Westkai, sechs Uhr morgens, sechs Uhr abends. Als Kind durfte ich einmal am Seil ziehen. Das Museum hat sie hinter Glas gehängt, wo niemand sie hört.")
    ui.talk("Vardon", "Ich habe es zuerst richtig versucht. Leihgabe, Ausstellung, Sponsoring. Frau Revik hat Nein gesagt. Danach habe ich zu Marek Dane gesagt: Finden Sie einen Weg. Ich wollte keine Details hören. Das war der Punkt, an dem ich hätte aufhören müssen.")
    ui.talk("Vardon", "Dane sprach von einem Privatsammler, von einer zweiten Glocke aus derselben Gießerei. Deshalb Daal, deshalb das Reparaturzeichen: Ich wollte wissen, ob man die beiden unterscheiden kann. Ich wollte, dass es nicht die aus dem Museum ist.")
    ui.talk("Vardon", "Am Abend nach dem Einbruch zeigten die Nachrichten ein Foto. Drei Striche im Kreis. Da wusste ich es. Ich habe geschrieben, dass es vorbei ist. Dann rief Dane an: Wenn ich aussteige, geht sie an einen Händler, der sie einschmilzt, und meine Anzahlung ist weg. Ich habe mir gesagt, ich rette sie.")
    ui.talk("Vardon", "Ich habe sie nicht gerettet. Ich wollte sie haben. So einfach und so hässlich ist das.")
    ui.talk("Wynn", "Wer hat sie gestohlen?")
    ui.talk("Vardon", "Ich weiß es nicht. Dane sprach vom ‚Treuhänder‘. Drei Tage vor dem Einbruch hat er mir geschrieben. Ich habe das als Lieferung gelesen. Weil ich es so lesen wollte.")
    ui.say("Sie entsperrt ihr Telefon und dreht es zu Wynn.")
    fakt(ui, Z, "dienstagnacht", "Nachricht von Dane an Vardon, drei Tage vor dem Diebstahl: „Der Treuhänder liefert, Dienstagnacht. Danach Funkstille.“ – Der Einbruch geschah in der Nacht von Dienstag auf Mittwoch.")
    if "vardon_sim" not in Z["fakten"]:
        fakt(ui, Z, "vardon_sim", "Vardon übergibt ihr Zweittelefon: Die SIM-Karte ist die Nummer des Chat-Gegenübers auf Danes Telefon.")
    aussage(ui, Z, "vardon_gestaendnis", "Elise Vardon: wollte die Glocke aus persönlichen Gründen (ihr Großvater läutete sie am Westkai); nach der Absage des Museums beauftragte sie Dane, „einen Weg zu finden“; sie redete sich ein, es gehe um eine zweite Glocke; nach den Abendnachrichten wusste sie es und machte unter Danes Druck weiter.")
    setf(Z, "vardon_gestaendnis", "dane_wusste", "nummer_id", "ev_id")
    frage(ui, Z, "ev", "geklärt", "„E. V.“ ist Elise Vardon; ihr gehört die Prepaid-Nummer aus dem Chat mit Dane.")
    frage(ui, Z, "cairn", "geklärt", "Der Konzern verfolgte ein legitimes Ausstellungsprojekt. Elise Vardon handelte privat: Sie wusste, dass das Museum nicht verkaufte, wollte keine Details hören und machte nach der Meldung weiter.")
    frage(ui, Z, "dane", "geklärt", "Ja – Dane kannte die Tatnacht drei Tage im Voraus („Dienstagnacht“).")


def w_dane(ui, Z):
    ui.title("Justizgebäude")
    ui.ort("Besprechungsraum der Staatsanwaltschaft")
    ui.say("Staatsanwältin Leni Hartmann hat zwei Bedingungen gestellt: volle Wahrheit, keine Rosinen. Marek Dane hört zu, die Hände gefaltet. Dann sieht er zu seiner Anwältin, die nickt.")
    ui.talk("Dane", "Gut. Kein Theater mehr.")
    ui.talk("Dane", "Vardon kam vor drei Wochen, nach der Absage des Museums. Sie wollte die Glocke. Ich kannte jemanden, der Dinge möglich macht: Ivo Serrat. Er sagte: ‚Museum verkauft nicht. Wir lösen das.‘ Ich wusste, was das heißt. Spätestens, als er mir den Tag nannte. Dienstagnacht.")
    ui.talk("Dane", "Ich habe die Halterung bestellt und die Lagerung bei Harborlight über Morrow laufen lassen, damit mein Name nicht draufsteht. Morrow wusste nichts – er wollte nichts wissen. Das ist nicht dasselbe, aber es ist auch nicht wenig.")
    ui.talk("Dane", "Der Chat auf meinem Telefon – das war nicht Rusk. Das war Vardon. Ich habe gelogen, weil ich dachte: Eine Käuferin, die aussteigt, ist ein Problem. Ein Fahrer, der aussteigt, ist nur ein Fahrer.")
    ui.talk("Dane", "Mein zweites Telefon liegt in einem Schließfach am Hauptbahnhof. Fach 212. Da ist alles drauf, was Serrat mir geschrieben hat.")
    ui.say("Fach 212 enthält ein billiges Telefon in einer Plastiktüte. Die Forensik braucht vier Stunden.")
    fakt(ui, Z, "dane_handy", "Danes Zweittelefon (Schließfach 212, Hauptbahnhof): Nachrichten von „Treuhänder“ – „Museum verkauft nicht. Wir lösen das.“ und „Dienstagnacht. Zollhof C. Danach du.“ Die Zahlungen gehen an ein Konto, über das auch die Büromiete von Serrat Konsultationen läuft.")
    fakt(ui, Z, "vardon_nummer_bestaetigt", "Funkzellendaten: Die Chat-Nummer war nachts regelmäßig in der Zelle von Vardons Wohnadresse eingeloggt.")
    aussage(ui, Z, "dane_gestaendnis", "Marek Dane (Geständnis): Vardon beauftragte ihn nach der Absage des Museums; er bezog Ivo Serrat ein und kannte die Tatnacht im Voraus; er organisierte Halterung, Lagerung (über Morrow) und den Transport mit Rusk; das Chat-Gegenüber war Vardon, nicht Rusk.")
    setf(Z, "dane_gestaendnis", "dane_wusste", "nummer_id", "ev_id", "serrat_name", "trh_kanal")
    frage(ui, Z, "dane", "geklärt", "Ja – Dane kannte den Plan und die Tatnacht im Voraus; er hat es gestanden, sein Zweittelefon belegt es.")
    frage(ui, Z, "ev", "geklärt", "„E. V.“ ist Elise Vardon; ihr gehört die Chat-Nummer (Geständnis Dane, Funkzellendaten).")
    frage(ui, Z, "morrow", "geklärt", "Morrow kannte den Inhalt vor dem Diebstahl nicht; er wollte es nicht wissen – und buchte nach der Meldung trotzdem weiter.")


def w_falle(ui, Z):
    ui.title("Speicher 9")
    ui.ort("Westkai · 21:00 Uhr")
    quelle = "Sens" if hat(Z, "sen_telefon") else "Kess'" if hat(Z, "kess_telefon") else "Danes"
    ui.say(f"Wynn schreibt über {quelle} Telefon in den Kanal TRH-7: ‚Neuer Kunde. Objekt aus dem Westkai-Bestand. Will den Treuhänder persönlich sehen. Speicher 9, 21 Uhr.‘ Die Antwort kommt nach elf Minuten: ‚Einverstanden.‘")
    ui.talk("Wynn", "Wer sich Kunden als Treuhänder verkauft, muss die Kunden sehen. Das ist seine Eitelkeit, und das ist unsere Chance. Mein Kollege spielt den Kunden. Ich frage die Unit konkret an: Der Steg ist nass, das Becken tief, und Serrat kann jeden in seiner Nähe für ein paar Sekunden taumeln lassen. Sorgt dafür, dass dabei niemand ins Wasser geht.")
    sel, opfer, cov = gefahr_mission(ui, Z, "Westkai", ROLLEN_KAI, KAI_ZEILE, KAI_TOD,
                                     extra=0.10 if hat(Z, "serrat_gewarnt") else 0.0)
    ui.say("21:04 Uhr. Ivo Serrat kommt zu Fuß, mit Regenschirm, als käme er aus der Oper. Er gibt dem verdeckten Ermittler die Hand, lächelt, und in dem Moment, in dem die Beamten aus dem Schatten treten, kippt der Ermittler seitlich weg, als hätte jemand den Steg gedreht.")
    if any(m in sel for m in ROLLEN_KAI["Halt an der Kante"]):
        ui.say("Die Planken halten ihn. Er taumelt, fängt sich am Geländer, und das Geländer gibt nicht nach.")
    else:
        ui.say("Der Ermittler geht über die Kante. Bevor jemand die Leiter erreicht, hebt sich das Wasser unter ihm und schiebt ihn sanft an die Sprossen – Nadi Rahman, Breakwater, die am Westkai wohnt und Lärm gehört hat. Sie nickt nur und verschwindet wieder.")
        Z["log"].append("Zwischenfall: verdeckter Ermittler ins Hafenbecken gestürzt, von Nadi Rahman gerettet")
    if any(m in sel for m in ROLLEN_KAI["Ortung"]):
        ui.say("Serrat dreht sich zur Containergasse – und läuft in Licht und Beamte. Er versucht nicht einmal, das Telefon loszuwerden.")
        fakt(ui, Z, "serrat_handy", "Serrats Telefon: kompletter Verlauf des Kanals TRH-7, darunter „Zollhof C, Dienstag 02:00. Wand hinten links, alte Naht.“ an V. K. und S. S. sowie „Museum verkauft nicht. Wir lösen das.“ an M. D.")
        setf(Z, "serrat_handy")
    else:
        ui.say("Serrat verschwindet zwischen den Containern. Drei Minuten später holen ihn zwei Beamte am Zaun ein. Unterwegs hat er etwas ins Becken geworfen. Ein kleines Platschen, sagt ein Beamter.")
    ui.talk("Serrat", "Detective Wynn. Ich hätte Sie für einen Mann gehalten, der Formulare mag.")
    ui.talk("Wynn", "Ich mag Formulare. Das hier ist eins. Haftbefehl.")
    fakt(ui, Z, "festnahme_serrat", "Ivo Serrat wurde am Westkai, Speicher 9, beim Treffen mit einem verdeckten Ermittler festgenommen, nachdem er über TRH-7 einen Folgeauftrag angenommen hatte.")
    setf(Z, "serrat_fest", "in_flagranti", "serrat_name")


WEGE_FN = {"durchsuchung": w_durchsuchung, "vardon": w_vardon, "dane": w_dane, "falle": w_falle}
WEGE_TXT = {
    "durchsuchung": "Serrats Geschäftsräume in der Börsengasse durchsuchen lassen",
    "vardon": "Elise Vardon mit allem vernehmen lassen, was vorliegt",
    "dane": "Der Staatsanwaltschaft ein Gespräch mit Marek Dane vorschlagen",
}


def zweite(ui, Z):
    rest = [k for k in ["durchsuchung", "vardon", "dane"]
            if k not in Z["k3_done"] and (k != "vardon" or hat(Z, "ev_id"))]
    if not rest:
        return
    ui.title("Lagebesprechung")
    ui.ort("Präsidium · Nachmittag")
    if hat(Z, "serrat_fest"):
        ui.talk("Wynn", "Serrat sitzt. Jetzt machen wir den Rest wasserdicht. Eine Sache schaffen wir heute noch.")
    else:
        ui.talk("Wynn", "Eine Sache schaffen wir noch, bevor wir Serrat stellen. Was bringt uns am meisten?")
    k = rest[ui.choose([WEGE_TXT[x] for x in rest], Z, save=True)]
    WEGE_FN[k](ui, Z)
    Z["k3_done"].append(k)
    ui.pause()


# ───────────────────────────── Finale ─────────────────────────────

def finale(ui, Z):
    ui.title("Fährterminal Ostmole")
    ui.ort("19:40 Uhr")
    if not hat(Z, "serrat_faehre"):
        ui.say("Am frühen Abend meldet die Hafenpolizei: Ein I. Serrat hat eine Kabine auf der 20-Uhr-Fähre nach Port Halden gebucht.")
        fakt(ui, Z, "faehre", "Ivo Serrat hat für 20:00 Uhr eine Kabine auf der Fähre nach Port Halden (Fährterminal Ostmole) gebucht.")
    ui.say("Der Wartebereich ist voll: Pendler, eine Schulklasse, Rentner mit Fahrrädern. Ivo Serrat sitzt in der hinteren Reihe, die Zeitung aufgeschlagen, und liest sie tatsächlich.")
    ui.talk("Wynn", "Ich habe einen Haftbefehl, dreihundert Passagiere und einen Mann, der jedem in seiner Nähe für ein paar Sekunden den Boden unter den Füßen wegziehen kann – auf einer Gangway über dem Hafenbecken. Wie machen wir das?")
    s = staerke(Z)
    opts = ["[GEFAHR] Zugriff im Terminal – die Unit sichert Passagiere und Gangway",
            "Die Fähre auslaufen lassen – Festnahme bei Ankunft in Port Halden per Amtshilfe (sicher, aber Serrat ist neun Stunden ohne Aufsicht an Bord)",
            "Wynn spricht Serrat an und bietet ihm an, sich zu stellen – mit allem, was gegen ihn vorliegt"]
    k = ui.choose(opts, Z)
    if k == 0:
        ui.talk("Wynn", "Ich frage die Unit konkret an: Haltet die Menschen von der Kante fern. Den Rest machen wir.")
        sel, opfer, cov = gefahr_mission(ui, Z, "Fährterminal", ROLLEN_TERMINAL, TERMINAL_ZEILE, TERMINAL_TOD,
                                         extra=0.05)
        ui.say("Als die Beamten auf ihn zugehen, faltet Serrat die Zeitung zusammen – und die drei Menschen, die ihm am nächsten stehen, verlieren gleichzeitig das Gleichgewicht. Die Menge weicht zurück, Richtung Gangway.")
        if any(m in sel for m in ROLLEN_TERMINAL["Gangway"]):
            ui.say("Die Gangway hält, die Stufen halten, niemand geht über die Kante.")
        else:
            ui.say("Auf der Gangway stürzen zwei Passagiere übereinander. Ein Mann bricht sich das Handgelenk.")
            Z["log"].append("Zwischenfall: Passagier verletzt (Gangway nicht gesichert)")
        if any(m in sel for m in ROLLEN_TERMINAL["Ortung"]):
            ui.say("Serrat versucht, im Gedränge zu verschwinden, aber es gibt keinen Winkel im Terminal, den heute niemand sieht. Zwei Beamte nehmen ihn am Ausgang zur Mole fest – das Telefon noch in der Manteltasche.")
            fakt(ui, Z, "serrat_handy", "Serrats Telefon: kompletter Verlauf des Kanals TRH-7, darunter „Zollhof C, Dienstag 02:00. Wand hinten links, alte Naht.“ an V. K. und S. S. sowie „Museum verkauft nicht. Wir lösen das.“ an M. D.")
            setf(Z, "serrat_handy")
        else:
            ui.say("Serrat schafft es bis zur Kaimauer, bevor ihn zwei Beamte stellen. Sein Telefon fliegt in hohem Bogen ins Becken.")
        ui.talk("Serrat", "Detective. Ich hatte gehofft, Sie würden mir die Überfahrt gönnen.")
        fakt(ui, Z, "festnahme_serrat", "Ivo Serrat wurde im Fährterminal Ostmole festgenommen.")
    elif k == 1:
        ui.say("Die Fähre legt pünktlich ab. Wynn sieht ihr nach, bis die Lichter klein werden. Um 05:10 Uhr nimmt die Polizei von Port Halden Ivo Serrat an der Gangway fest – höflich, ohne Widerstand.")
        ui.say("Sein Telefon ist auf Werkseinstellungen zurückgesetzt. Neun Stunden sind eine lange Zeit.")
        fakt(ui, Z, "festnahme_serrat", "Ivo Serrat wurde bei der Ankunft in Port Halden festgenommen; sein Telefon war zurückgesetzt.")
    else:
        ui.say("Wynn setzt sich neben Serrat, als wären sie zwei Pendler. Er legt eine Mappe auf die Zeitung.")
        ui.talk("Wynn", "Kein Theater, Herr Serrat. Sie können sich das ansehen und mitkommen. Oder Sie lassen es.")
        if s >= 5:
            ui.say("Serrat blättert. Er liest jede Seite, als prüfe er einen Vertrag. Dann schließt er die Mappe.")
            ui.talk("Serrat", "Ich bin Kaufmann, Detective. Ich weiß, wann ein Geschäft verloren ist.")
            ui.say("Er steht auf, knöpft den Mantel zu, und als er an der Kaimauer vorbeigeht, fällt etwas aus seiner Hand ins Wasser. Ein kleines Platschen. Wynn sagt nichts dazu.")
            fakt(ui, Z, "festnahme_serrat", "Ivo Serrat stellte sich im Fährterminal Ostmole; sein Telefon warf er ins Hafenbecken.")
        else:
            ui.say("Serrat blättert, lächelt und klappt die Mappe zu.")
            ui.talk("Serrat", "Dünn, Detective. Sehr dünn. Wir sehen uns – irgendwann.")
            ui.say("Wynn will aufstehen, und für drei Sekunden weiß er nicht, wo der Boden ist. Als er wieder steht, ist Serrat in der Menge an der Gangway verschwunden. Die Fähre legt ab.")
            ui.say("Um 05:10 Uhr nimmt die Polizei von Port Halden ihn an der Gangway fest. Sein Telefon ist zurückgesetzt. Wynn hat eine Schramme am Kinn und schlechte Laune.")
            Z["log"].append("Zwischenfall: Serrat entkam im Terminal kurzzeitig, Wynn leicht verletzt")
            fakt(ui, Z, "festnahme_serrat", "Ivo Serrat entkam im Fährterminal und wurde bei der Ankunft in Port Halden festgenommen; sein Telefon war zurückgesetzt.")
    setf(Z, "serrat_fest")
    ui.pause()


# ───────────────────────────── Fallabschluss ─────────────────────────────

def fallabschluss(ui, Z):
    ui.title("Fallabschluss: Die Hafenglocke")
    s = staerke(Z)
    if hat(Z, "nummer_id"):
        frage(ui, Z, "ev", "geklärt", "Elise Vardon – sie ist „E. V.“ und nutzte die Prepaid-Nummer im Chat mit Dane.")
    if s >= 4:
        frage(ui, Z, "org", "geklärt", "Den Einbruch organisierte Ivo Serrat („Treuhänder“, Code TRH-7), ausgeführt von Vera Kess und Samir Sen; Lagerung und Transport organisierte Marek Dane – über Morrow, Harborlight und den Fahrer Rusk.")
    else:
        frage(ui, Z, "org", "teilweise", "Ivo Serrat gilt als Organisator; die Beweislage gegen ihn ist dünn. Lagerung und Transport organisierte Dane.")
    if hat(Z, "dane_wusste"):
        frage(ui, Z, "dane", "geklärt", "Ja – Dane kannte die Tatnacht im Voraus.")
    if hat(Z, "dane_gestaendnis", "ledger") or "morrow" in Z["aussagen"]:
        frage(ui, Z, "morrow", "geklärt", "Morrow kannte den Inhalt vor dem Diebstahl nicht; ab der Meldung hatte er einen Verdacht und machte trotzdem weiter.")
    else:
        frage(ui, Z, "morrow", "teilweise", "Morrow taucht in keiner Unterlage des Einbruchs auf; ein Vorwissen ist nicht belegt.")
    if hat(Z, "vardon_gestaendnis", "dane_gestaendnis") or ("cairn_projekt" in Z["fakten"] and hat(Z, "vardon_anzahlung")):
        frage(ui, Z, "cairn", "geklärt", "Der Konzern war nur an einer legitimen Identifizierung interessiert; Elise Vardon handelte privat und wusste, dass das Museum nicht verkaufte.")
    if Z["fragen"]["depot"][0] != "geklärt":
        frage(ui, Z, "depot", "teilweise", "Corvin Daal meldete sich nach den Festnahmen selbst: Er sei die Person im Depot gewesen. Seine Angaben werden noch geprüft.")
    ui.pause()

    ui.title("Verfahren")
    zeilen = [
        f"Ivo Serrat / Misrule – Untersuchungshaft; Anklage wegen Organisation des Museumseinbruchs. Beweislage: {staerke_text(Z)}.",
        "Vera Kess / Faultline – Anklage wegen Einbruchdiebstahls und Körperverletzung am Wachmann"
        + ("; die Kronzeugenregelung ist beantragt." if hat(Z, "kronzeugin") else "."),
        "Samir Sen / Gloam – " + ("Anklage wegen Beihilfe zum Einbruchdiebstahl." if hat(Z, "festnahme_sen")
                                   else "flüchtig, zur Fahndung ausgeschrieben."),
        "Marek Dane – " + ("Anklage wegen Beihilfe zum Diebstahl, Hehlerei und Nötigung"
                           + ("; sein Geständnis wirkt strafmildernd." if hat(Z, "dane_gestaendnis") else ".")
                           if hat(Z, "dane_wusste") else "Anklage wegen Hehlerei; Vorwissen über den Einbruch nicht nachweisbar."),
        "Elise Vardon – " + ("Anklage wegen versuchter Hehlerei; eine Anstiftung zum Diebstahl ist nicht nachweisbar. Sie hat ihre Funktion bei Cairn niedergelegt."
                             if hat(Z, "nummer_id", "vardon_gestaendnis") else "Ermittlungen wegen Hehlerei dauern an."),
        "Cairn Maritime Holdings – keine Beteiligung des Konzerns; der Identifizierungsauftrag gehörte zu einem legitimen Ausstellungsprojekt.",
        "Elias Morrow – Verfahren wegen Beihilfe zur Hehlerei.",
        "Kellan Rusk – Verfahren wegen Begünstigung und Widerstand" + ("; seine Aussage wird ihm angerechnet." if "rusk" in Z["aussagen"] else "."),
        "Gerrit Voss – Bußgeld wegen fehlender Identitätsprüfung; keine Tatbeteiligung nachweisbar.",
        "Corvin Daal – entlastet; seine Identifizierungsarbeit war legal und dokumentiert.",
    ]
    for z in zeilen:
        ui.note("info", z)
    ui.pause()

    ui.title("Westkai, sechs Uhr")
    ui.ort("Eine Woche später · 06:00 Uhr")
    ui.say("Die Restaurierungsprüfung findet keinen neuen Schaden – bis auf einen frischen Kratzer neben dem alten Reparaturzeichen, wo die Holzhalterung gescheuert hat. Sanna Revik lässt ihn nicht wegpolieren. ‚Jetzt hat sie zwei Geschichten‘, sagt sie, und dokumentiert beide.")
    ui.say("Für einen Morgen darf die Glocke zurück an den Westkai. Hanne Krüger hat es organisiert, mit Klapptischen und Thermoskannen wie beim Kaimauerfest. Hafenarbeiter in Warnwesten, Rentner, ein paar Kinder, die nicht wissen, warum sie so früh aufstehen mussten.")
    if Z["tot"]:
        namen = ", ".join(TEAM[k] for k in Z["tot"])
        ui.say(f"Um sechs Uhr schlägt die Glocke den Schichtwechsel, so wie früher. Dann lässt Revik sie ein zweites Mal schlagen. Niemand muss erklären, für wen. Für {namen}.")
    else:
        ui.say("Um sechs Uhr schlägt die Glocke den Schichtwechsel, so wie früher. Der Ton ist tiefer, als alle erwartet haben, und hält länger, als irgendwer den Atem anhalten kann.")
    if "Nico" not in Z["tot"]:
        ui.say("Elena Bell steht weiter hinten, ohne Kamera, ohne Team. Sie fragt Nico leise, ob sie darüber etwas posten darf.")
        ui.talk("Nico", "Ich erzähl's selbst. Vielleicht schlecht. Aber selbst.")
        ui.talk("Elena", "Dann les ich's.")
    ui.talk("Wynn", f"Danke. Und das meine ich fürs Protokoll, {L(Z)}.")
    ui.say("Am Nachmittag aktualisiert der Vesper-Einsatzindex die Mercer Unit – zum ersten Mal mit genug Daten für eine echte Wertung. Die Publikumsliste bemerkt es nicht. Das ist in Ordnung.")
    ui.pause()


NAECHSTE = [
    "Neri Sol / Slipmark wird bei einem Juweliereinbruch beobachtet – die Seitenlinie sucht einen neuen Vermittler, jetzt, wo Serrat sitzt",
    "Ronan Vale / Keystone fordert öffentlich klare Führungsstrukturen für kleine Teams – und lädt die Mercer Unit zur Debatte ein",
    "Nadi Rahman / Breakwater meldet sich: Am Westkai stimmt etwas mit den Fluttoren nicht",
    "Eine ruhige Woche: Liora Venn lädt die Unit ins Atelier Hinterhof 12 ein",
]


def ausblick(ui, Z):
    ui.title("Wie geht es weiter?")
    ui.say("Der Fall der Hafenglocke ist abgeschlossen. Vesper City schläft nicht.")
    k = ui.choose(NAECHSTE, Z)
    Z["naechster_fall"] = NAECHSTE[k]
    ui.note("info", "Deine Wahl ist gespeichert. Der KI-Erzähler kann die Geschichte genau hier fortsetzen.")


def spielen(ui, Z):
    if Z["phase"] == "start":
        ui.kapitel_karte(3, "Glockenschlag", "Der Treuhänder")
        ui.ort("Am nächsten Morgen")
        weg = Z["k3_weg"] or "durchsuchung"
        WEGE_FN[weg](ui, Z)
        Z["k3_done"].append(weg)
        ui.pause()
        Z["phase"] = "zweite"
    if Z["phase"] == "zweite":
        zweite(ui, Z)
        Z["phase"] = "finale"
    if Z["phase"] == "finale":
        if not hat(Z, "serrat_fest"):
            finale(ui, Z)
        Z["phase"] = "abschluss"
    if Z["phase"] == "abschluss":
        fallabschluss(ui, Z)
        ausblick(ui, Z)
        Z["kapitel"], Z["phase"] = 4, "ende"
