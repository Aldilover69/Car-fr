# -*- coding: utf-8 -*-
"""
AFTERHOURS – Spielkern.
Spielstand, Fallakte, Team, gefährliche Missionen und die Schnittstelle,
die sowohl die Terminal- als auch die Grafikversion umsetzen.
"""
import json
import os
import random

BASIS = os.path.dirname(os.path.abspath(__file__))
SPIELSTAND = os.path.join(BASIS, "spielstand.json")


class Abbruch(Exception):
    """Spieler kehrt ins Hauptmenü zurück."""


class Spielende(Exception):
    """Die Geschichte kann nicht weitergehen (z. B. niemand mehr einsatzfähig)."""


# ───────────────────────────── Oberflächen-Schnittstelle ─────────────────────────────

class UI:
    """Terminal und Grafik setzen diese Methoden um. Die Geschichte ruft nur sie auf."""

    def title(self, sub):              # Kapitel-/Szenenüberschrift
        raise NotImplementedError

    def ort(self, text):               # Ort und Uhrzeit
        raise NotImplementedError

    def say(self, text):               # Erzähltext
        raise NotImplementedError

    def talk(self, who, text):         # Dialogzeile
        raise NotImplementedError

    def note(self, kind, text):        # fakt | aussage | frage | warn | tod | info
        raise NotImplementedError

    def pause(self):
        raise NotImplementedError

    def choose(self, options, Z, save=False):   # gibt Index zurück
        raise NotImplementedError

    def ask_text(self, prompt, secret=False):
        raise NotImplementedError

    def stream_begin(self):
        raise NotImplementedError

    def stream(self, chunk):
        raise NotImplementedError

    def stream_end(self):
        raise NotImplementedError

    def busy(self, text):              # „Erzähler schreibt …“
        pass

    def kapitel_karte(self, nummer, titel, untertitel):
        self.title(f"Kapitel {nummer}: {titel}")
        self.note("info", untertitel)


# ───────────────────────────── Kanon: Team ─────────────────────────────

TEAM = {
    "Daniel": "Daniel Mercer / Recoil",
    "Mara": "Mara Ortiz / Latch",
    "Nico": "Nico Bell / Skid",
    "Asha": "Asha Okafor / Hush",
    "Imani": "Imani Darrow / Switch",
    "Leila": "Leila Chen / Lifeline",
    "Juno": "Juno Park / Apex",
}
SKILL = {
    "Daniel": "nimmt kinetische Energie auf, gibt sie gerichtet ab",
    "Mara": "verankert berührte Objekte an ihrer Position",
    "Nico": "steuert Reibung: Halt oder Rutschfläche",
    "Asha": "dämpft und fokussiert Schall",
    "Imani": "lenkt oder unterbricht Strom über Leitungen",
    "Leila": "bioelektrische Stabilisierung per Berührung",
    "Juno": "kurzlebige Trittflächen, Überblick von oben",
}
# Wer die Leitung übernimmt, falls die bisherige Leitung fällt
NACHFOLGE = ["Daniel", "Mara", "Imani", "Leila", "Nico", "Asha", "Juno"]

FRAGEN = {
    "ev": "Wer steckt hinter der unbekannten Nummer und dem Kürzel „E. V.“?",
    "org": "Wer hat Diebstahl und Transport der Glocke tatsächlich organisiert?",
    "dane": "Wusste Dane vor dem Diebstahl von einer rechtswidrigen Beschaffung?",
    "morrow": "Was wusste Elias Morrow über den Inhalt der Kiste?",
    "cairn": "Wusste jemand bei Cairn von der späteren Beschaffung?",
    "depot": "Wer fragte im Straßenbahndepot nach dem Reparaturzeichen?",
}

KAPITEL_TITEL = {1: "Die Reservierung", 2: "Drei Striche im Kreis", 3: "Glockenschlag"}


# ───────────────────────────── Spielstand ─────────────────────────────

def neu():
    return {
        "version": 2, "kapitel": 1, "phase": "start",
        "uhr": 22 * 60 + 15, "slots": 3, "done": [], "tier": "",
        "k2_done": [], "k3_done": [], "flags": [],
        "folge": "", "k3_weg": "", "naechster_fall": "",
        "fakten": {
            "glocke": "Die Hafenglocke wurde bei Kellan Rusk in einer Transportkiste sichergestellt und polizeilich gesichert.",
            "dane": "Marek Dane wurde am überwachten Übergabepunkt Tor 4 nach einem Fluchtversuch festgesetzt.",
            "halter": "Harborlight, Lagerplatz N-14: Eine maßgefertigte Holzhalterung passt zur Kiste der Glocke; Rechnung über „Sicherung und Umlagerung eines historischen Metallobjekts“, bezahlt über Danes Vermittlungscode im Namen von Morrow Acquisitions Services.",
            "cairn": "Cairn Maritime Holdings zahlte Corvin Daal sechs Tage vor dem Diebstahl 3.200 VC für „historische Objektidentifizierung – Katalog B-17“.",
        },
        "aussagen": {
            "voss": "Gerrit Voss (Harborlight): Die Lagerung organisierte ein „M. Dane“; Identität nicht geprüft, vom Inhalt nichts gewusst.",
            "morrow0": "Elias Morrow: habe nur eine Lagerung für einen Kunden organisiert, den Inhalt nicht gekannt.",
            "chat": "Chat auf Danes Telefon: Das Gegenüber schreibt „Ich habe dem Transport zugestimmt, nicht dem Diebstahl“ – Identität unbestätigt.",
        },
        "fragen": {k: ["offen", ""] for k in FRAGEN},
        "tot": [], "log": [], "ergebnis": "",
    }


def speichern(Z, pfad=None):
    pfad = pfad or SPIELSTAND
    tmp = pfad + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(Z, fh, ensure_ascii=False, indent=1)
    os.replace(tmp, pfad)


def laden(pfad=None):
    pfad = pfad or SPIELSTAND
    if not os.path.exists(pfad):
        return None
    try:
        with open(pfad, encoding="utf-8") as fh:
            Z = json.load(fh)
    except (OSError, ValueError):
        return None
    basis = neu()
    for k, v in basis.items():   # ältere Spielstände ergänzen
        Z.setdefault(k, v)
    return Z


def spielstand_info(Z):
    if not Z:
        return ""
    if Z.get("kapitel", 1) > 3:
        return "Fall abgeschlossen"
    return f"Kapitel {Z['kapitel']}: {KAPITEL_TITEL.get(Z['kapitel'], '')}"


# ───────────────────────────── Flags & Fallakte ─────────────────────────────

def setf(Z, *namen):
    for n in namen:
        if n not in Z["flags"]:
            Z["flags"].append(n)


def hat(Z, *namen):
    return any(n in Z["flags"] for n in namen)


def fakt(ui, Z, k, t):
    if k not in Z["fakten"]:
        Z["fakten"][k] = t
        ui.note("fakt", t)


def aussage(ui, Z, k, t):
    if k not in Z["aussagen"]:
        Z["aussagen"][k] = t
        ui.note("aussage", t)


def frage(ui, Z, k, status, t=""):
    if Z["fragen"][k] == [status, t]:
        return
    rang = {"offen": 0, "teilweise": 1, "geklärt": 2}
    if rang[status] < rang[Z["fragen"][k][0]]:
        return  # nie zurückstufen
    Z["fragen"][k] = [status, t]
    ui.note("frage", f"[{status}] {FRAGEN[k]}" + (f" – {t}" if t else ""))


def geklaert_anzahl(Z):
    return sum(1 for v in Z["fragen"].values() if v[0] == "geklärt")


def akte_daten(Z):
    """Für die Anzeige: (Fakten, Aussagen, Fragen[(status, frage, notiz)])."""
    fr = [(Z["fragen"][k][0], txt, Z["fragen"][k][1]) for k, txt in FRAGEN.items()]
    return list(Z["fakten"].values()), list(Z["aussagen"].values()), fr


# ───────────────────────────── Team, Leitung, Missionen ─────────────────────────────

def lebend(Z):
    return [k for k in TEAM if k not in Z["tot"]]


def leiter(Z):
    for k in NACHFOLGE:
        if k not in Z["tot"]:
            return k
    return None


def L(Z):
    """Vorname der aktuellen Leitung (Spielerfigur)."""
    return leiter(Z) or "niemand"


def auswahl(ui, Z, rollen, n=3):
    lv = lebend(Z)
    n = min(n, len(lv))
    ui.say(f"Wähle {n} Einsatzkräfte. Gebraucht wird: "
           + " · ".join(f"{r} ({', '.join(m for m in ms if m in lv) or 'niemand verfügbar'})"
                        for r, ms in rollen.items()))
    gew = []
    while len(gew) < n:
        frei = [k for k in lv if k not in gew]
        ab = [r for r, ms in rollen.items() if any(m in gew for m in ms)]
        if gew:
            ui.note("info", f"Gewählt: {', '.join(gew)} · abgedeckt: {', '.join(ab) or '–'}")
        gew.append(frei[ui.choose([f"{TEAM[k]} – {SKILL[k]}" for k in frei], Z)])
    return gew


def gefahr_mission(ui, Z, name, rollen, zeilen, tod_zeilen, basis=0.60, extra=0.0, n=3):
    """
    Vereinbarte Mechanik: Nur bei einer ausdrücklich gewählten gefährlichen Mission
    können ein oder zwei der tatsächlich ausgewählten Helden sterben.
    Gibt (auswahl, opfer, abdeckung) zurück.
    """
    sel = auswahl(ui, Z, rollen, n)
    cov = sum(any(m in sel for m in ms) for ms in rollen.values())
    p = min(0.75, max(0.10, basis - 0.15 * cov + extra))
    label = "hoch" if p >= 0.45 else "mittel" if p >= 0.3 else "gering"
    ui.note("warn", f"Abgedeckt: {cov} von {len(rollen)} Gefahrenbereichen. Geschätztes Risiko: {label}.")
    ui.pause()
    for m in sel:
        ui.say(zeilen[m])
    opfer = []
    if random.random() < p:
        k = 2 if (len(sel) > 1 and random.random() < 0.25) else 1
        opfer = random.sample(sel, k)
        alter_leiter = leiter(Z)
        for o in opfer:
            ui.note("tod", tod_zeilen[o])
            Z["tot"].append(o)
        Z["log"].append(f"Verlust ({name}): " + ", ".join(TEAM[o] for o in opfer))
        nach_verlust(ui, Z, alter_leiter)
    return sel, opfer, cov


def nach_verlust(ui, Z, alter_leiter):
    neu_l = leiter(Z)
    if neu_l is None:
        raise Spielende("Von der Mercer Unit ist niemand mehr übrig, der die Geschichte weitertragen könnte.")
    if alter_leiter and neu_l != alter_leiter:
        ui.say(f"{TEAM[alter_leiter]} hat die Leitung nie für sich allein beansprucht. "
               f"Jetzt liegt sie bei {TEAM[neu_l]}. Niemand stimmt darüber ab – es ist einfach klar.")
        ui.note("info", f"Leitungswechsel: Du spielst ab jetzt {TEAM[neu_l]}.")
        Z["log"].append(f"Leitungswechsel: {TEAM[neu_l]}")


# ───────────────────────────── Spielablauf ─────────────────────────────

def spiel(ui, Z):
    """Spielt die Kapitel ab dem gespeicherten Stand. Gibt Z zurück."""
    import kapitel1
    import kapitel2
    import kapitel3
    kap = {1: kapitel1.spielen, 2: kapitel2.spielen, 3: kapitel3.spielen}
    try:
        while Z["kapitel"] in kap:
            if Z["phase"] == "start":
                speichern(Z)
            kap[Z["kapitel"]](ui, Z)
            speichern(Z)
    except Spielende as e:
        ui.title("Ende")
        ui.say(str(e))
        Z["phase"] = "spielende"
        speichern(Z)
    return Z
