# -*- coding: utf-8 -*-
"""AFTERHOURS – Terminal-Oberfläche."""
import getpass
import os
import sys
import textwrap

import engine
from engine import TEAM, SKILL

W = 80
os.system("")  # ANSI-Farben unter Windows aktivieren
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def _f(code, t):
    return f"\033[{code}m{t}\033[0m"


bold = lambda t: _f("1", t)
dim = lambda t: _f("2", t)
red = lambda t: _f("31", t)
green = lambda t: _f("32", t)
yellow = lambda t: _f("33", t)
cyan = lambda t: _f("36", t)


def wrap(t, **kw):
    return textwrap.fill(t, W, **kw)


def eingabe(prompt="> "):
    try:
        return input(prompt)
    except (EOFError, KeyboardInterrupt):
        print("\nSpiel beendet.")
        sys.exit(0)


class TerminalUI(engine.UI):
    def __init__(self):
        self.ki_stand = None
        self._zeile = ""

    def title(self, sub):
        print("\n" + bold("█ AFTERHOURS") + f" – {sub}")
        print(dim("─" * W) + "\n")

    def ort(self, text):
        print(cyan("  " + text) + "\n")

    def say(self, text):
        for p in text.strip().split("\n"):
            print(wrap(p) if p.strip() else "")
        print()

    def talk(self, who, text):
        print(wrap(f"{bold(who)}: „{text}“", subsequent_indent="    ") + "\n")

    def note(self, kind, text):
        lab = {"fakt": green("  ✚ Beweis: "), "aussage": yellow("  ✚ Aussage: "),
               "frage": cyan("  ◆ Frage: "), "warn": red("  ! "), "tod": red("  † "),
               "info": dim("  · ")}[kind]
        if kind == "tod":
            text = red(text)
        print(wrap(lab + text, subsequent_indent="    ") + "\n")

    def pause(self):
        eingabe(dim("   ⏎ weiter "))
        print()

    def akte(self, Z):
        f, a, fr = engine.akte_daten(Z)
        print("\n" + bold("═" * 22 + " FALLAKTE: HAFENGLOCKE " + "═" * 22))
        print("\n" + green(bold("BEWIESENE FAKTEN")))
        for t in f:
            print(wrap("• " + t, subsequent_indent="  "))
        print("\n" + yellow(bold("AUSSAGEN (nicht bewiesen)")))
        for t in a:
            print(wrap("• " + t, subsequent_indent="  "))
        print("\n" + red(bold("OFFENE FRAGEN")))
        for st, txt, note in fr:
            farbe = {"offen": red, "teilweise": yellow, "geklärt": green}[st]
            print(wrap(f"• [{farbe(st)}] {txt}" + (f" – {note}" if note else ""), subsequent_indent="  "))
        print()

    def team(self, Z):
        print("\n" + bold("═══ MERCER UNIT ═══"))
        l = engine.leiter(Z)
        for k, n in TEAM.items():
            st = red("† gefallen    ") if k in Z["tot"] else green("einsatzbereit")
            mark = yellow(" (Leitung)") if k == l else ""
            print(f" {n:<24} {st}  {dim(SKILL[k])}{mark}")
        print(" Theo Alvarez / Relay     Technik und Kommunikation (nicht im Feld)")
        print(dim(" In Erinnerung: Priya Nair / Liminal.\n"))

    def choose(self, options, Z, save=False):
        print()
        for i, o in enumerate(options, 1):
            txt = o.replace("[GEFAHR]", red("[GEFAHR]"))
            print(wrap(f"{bold(str(i))}) {txt}", initial_indent="  ", subsequent_indent="     "))
        print(dim("\n  [a] Fallakte  [t] Team" + ("  [s] Speichern" if save else "") + "  [q] Hauptmenü"))
        while True:
            e = eingabe("\n> ").strip().lower()
            if e.isdigit() and 1 <= int(e) <= len(options):
                print()
                return int(e) - 1
            if e == "a":
                self.akte(Z)
            elif e == "t":
                self.team(Z)
            elif e == "s" and save:
                engine.speichern(Z)
                print(green("  Spielstand gespeichert.\n"))
            elif e == "q":
                raise engine.Abbruch()

    def ask_text(self, prompt, secret=False):
        print(wrap(prompt))
        if secret:
            try:
                return getpass.getpass("> ")
            except (EOFError, KeyboardInterrupt):
                return ""
        return eingabe("> ")

    # KI-Ausgabe: zeilenweise, Markdown leicht aufbereitet
    def stream_begin(self):
        self._zeile = ""
        print()

    def stream(self, chunk):
        self._zeile += chunk
        while "\n" in self._zeile:
            z, self._zeile = self._zeile.split("\n", 1)
            self._md_zeile(z)

    def stream_end(self):
        if self._zeile:
            self._md_zeile(self._zeile)
        self._zeile = ""
        print()

    def _md_zeile(self, z):
        s = z.strip()
        if s.startswith("#"):
            print("\n" + bold("█ " + s.lstrip("#").strip().replace("**", "")))
            print(dim("─" * W))
        elif not s:
            print()
        elif s in ("---", "***"):
            print(dim("─" * W))
        else:
            ein = "  " if s.startswith(("- ", "* ")) else ""
            print(wrap(s.replace("**", ""), subsequent_indent=ein + "  " if ein else ""))
        sys.stdout.flush()

    def busy(self, text):
        if text:
            print(dim("  " + text))


def hauptmenue():
    ui = TerminalUI()
    while True:
        Z = engine.laden()
        print("\n" + bold("   A F T E R H O U R S"))
        print(dim("   Vesper City · Die gestohlene Hafenglocke\n"))
        opts, keys = [], []
        if Z and Z.get("phase") != "spielende" and Z["kapitel"] <= 3:
            opts.append(f"Fortsetzen ({engine.spielstand_info(Z)})")
            keys.append("weiter")
        opts.append("Neues Spiel (Kapitel 1–3)")
        keys.append("neu")
        import ki
        if ki.verlauf_laden():
            opts.append("KI-Erzähler fortsetzen")
            keys.append("ki_weiter")
        opts.append("KI-Erzähler neu starten" + (" (mit deinem Spielstand)" if Z and (Z["kapitel"] > 1 or Z["done"]) else ""))
        keys.append("ki_neu")
        opts.append("Beenden")
        keys.append("ende")
        for i, o in enumerate(opts, 1):
            print(f"  {bold(str(i))}) {o}")
        e = eingabe("\n> ").strip()
        if not (e.isdigit() and 1 <= int(e) <= len(opts)):
            continue
        k = keys[int(e) - 1]
        try:
            if k == "ende":
                return
            if k == "neu":
                Z = engine.neu()
                engine.speichern(Z)
                k = "weiter"
            if k == "weiter":
                Z = engine.spiel(ui, Z)
                if Z["kapitel"] > 3 and Z.get("phase") != "spielende":
                    if ui.choose(["Mit dem KI-Erzähler weiterspielen", "Zurück zum Hauptmenü"], Z) == 0:
                        ki.sitzung(ui, Z, neu=True)
            elif k == "ki_weiter":
                ki.sitzung(ui, Z, neu=False)
            elif k == "ki_neu":
                ki.sitzung(ui, Z, neu=True)
        except engine.Abbruch:
            print(dim("\n  Zurück im Hauptmenü. Gespeichert ist der Stand vom letzten Kapitelbeginn oder deinem letzten [s].\n"))
