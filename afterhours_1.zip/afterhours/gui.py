# -*- coding: utf-8 -*-
"""
AFTERHOURS – Grafikversion (pygame 2).
Die Geschichte läuft in einem eigenen Thread und spricht über GuiUI mit dem Fenster.
"""
import math
import os
import queue
import random
import threading
import traceback

import pygame

import engine
import ki
from engine import TEAM, SKILL

W, H = 1280, 720
MAIN = pygame.Rect(20, 20, 900, 680)
SIDE = pygame.Rect(932, 20, 328, 680)
TW = 800                                   # Textbreite
TX = MAIN.x + (MAIN.w - TW) // 2           # linker Textrand

BG_TOP, BG_BOT = (16, 18, 44), (5, 5, 12)
PANEL = (9, 11, 22, 228)
TEXT = (230, 232, 240)
DIM = (138, 146, 168)
ACCENT = (255, 184, 77)
CYAN = (98, 200, 230)
GREEN = (110, 214, 150)
YELLOW = (236, 200, 96)
RED = (238, 98, 98)
BTN, BTN_HI, BTN_RAND = (26, 30, 50), (42, 48, 80), (64, 72, 106)

NOTE_STIL = {  # Etikett, Etikettfarbe, Textfarbe
    "fakt": ("BEWEIS", GREEN, (192, 236, 206)),
    "aussage": ("AUSSAGE", YELLOW, (240, 224, 176)),
    "frage": ("FRAGE", CYAN, (178, 224, 240)),
    "warn": ("ACHTUNG", RED, (250, 176, 176)),
    "tod": ("GEFALLEN", RED, (255, 150, 150)),
    "info": ("INFO", DIM, (180, 186, 204)),
    "offen": ("OFFEN", RED, (230, 200, 200)),
    "teilweise": ("TEILWEISE", YELLOW, (240, 224, 176)),
    "geklärt": ("GEKLÄRT", GREEN, (192, 236, 206)),
}
LABEL_W = 92
ABBRUCH = object()
F = {}


def schrift(size, bold=False):
    return pygame.font.SysFont("segoeui,helveticaneue,helvetica,dejavusans,liberationsans,arial", size, bold=bold)


def schriften_laden():
    F["body"] = schrift(19)
    F["bold"] = schrift(19, True)
    F["note"] = schrift(17)
    F["small"] = schrift(15)
    F["smallb"] = schrift(15, True)
    F["label"] = schrift(12, True)
    F["h1"] = schrift(28, True)
    F["h2"] = schrift(22, True)
    F["btn"] = schrift(17)
    F["btnb"] = schrift(17, True)
    F["huge"] = pygame.font.SysFont("bahnschrift,impact,dejavusanscondensed,arialblack,arial", 84, bold=True)


_cache = {}


def txt(font, s, color):
    key = (id(font), s, color)
    surf = _cache.get(key)
    if surf is None:
        if len(_cache) > 4000:
            _cache.clear()
        if not s:   # leere Zeilen: manche pygame-Versionen lehnen leeren Text ab
            surf = pygame.Surface((1, max(1, font.get_height())), pygame.SRCALPHA)
        else:
            surf = font.render(s, True, color)
        _cache[key] = surf
    return surf


def umbrechen(font, text, breite, erste=None):
    """Bricht Text um. erste = Breite der ersten Zeile (für hängende Etiketten)."""
    zeilen = []
    for absatz in text.split("\n"):
        w = erste if (erste is not None and not zeilen) else breite
        cur = ""
        for wort in absatz.split(" "):
            test = wort if not cur else cur + " " + wort
            if font.size(test)[0] <= w:
                cur = test
                continue
            if cur:
                zeilen.append(cur)
                w = breite
            while font.size(wort)[0] > w and len(wort) > 1:     # überlange Wörter
                n = len(wort)
                while n > 1 and font.size(wort[:n])[0] > w:
                    n -= 1
                zeilen.append(wort[:n])
                wort = wort[n:]
            cur = wort
        zeilen.append(cur)
    return zeilen


def rrect(surf, color, rect, radius=10, width=0):
    pygame.draw.rect(surf, color, rect, width, border_radius=radius)


def pille(surf, x, y, text, farbe, breite=None):
    t = txt(F["label"], text, (12, 14, 24))
    w = breite or t.get_width() + 14
    rrect(surf, farbe, pygame.Rect(x, y, w, 20), 6)
    surf.blit(t, (x + (w - t.get_width()) // 2, y + (20 - t.get_height()) // 2))
    return w


def md_klar(s):
    return s.replace("**", "").replace("__", "")


# ───────────────────────────── Textblöcke ─────────────────────────────

class Block:
    """Ein Absatz im Geschichtsverlauf (Erzähltext, Dialog, Notiz …)."""

    def __init__(self, kind, data):
        self.kind, self.data = kind, data
        self.lw = None
        self.dirty = True
        self.items = []     # (x, y, font, farbe, text)
        self.deko = []      # ("pille", x, y, text, farbe, breite) | ("linie", y) | ("raute", x, y)
        self.h = 0
        self.total = 0
        self.shown = 0
        self.instant = kind in ("title", "ort", "wahl", "ki", "member", "kopf")
        self.top = 14 if kind in ("title", "kopf") else 10

    def layout(self, w):
        if self.lw == w and not self.dirty:
            return
        self.lw, self.dirty = w, False
        it, dk = [], []
        y = 0
        k = self.kind
        lh = lambda f: f.get_linesize() + 2
        if k == "title":
            dk.append(("text", 0, 0, "AFTERHOURS", F["label"], ACCENT))
            y = 18
            for z in umbrechen(F["h1"], self.data, w):
                it.append((0, y, F["h1"], (255, 255, 255), z))
                y += lh(F["h1"])
            y += 6
            dk.append(("linie", y))
            y += 6
        elif k == "kopf":
            for z in umbrechen(F["h2"], self.data, w):
                it.append((0, y, F["h2"], ACCENT, z))
                y += lh(F["h2"])
        elif k == "ort":
            dk.append(("raute", 4, 9))
            for z in umbrechen(F["small"], self.data, w - 20):
                it.append((20, y, F["small"], CYAN, z))
                y += lh(F["small"])
        elif k == "say":
            for z in umbrechen(F["body"], self.data, w):
                it.append((0, y, F["body"], TEXT, z))
                y += lh(F["body"])
        elif k == "talk":
            wer, was = self.data
            lab = wer + ":"
            lw_ = F["bold"].size(lab + " ")[0]
            it.append((0, 0, F["bold"], ACCENT, lab))
            for i, z in enumerate(umbrechen(F["body"], f"„{was}“", w, erste=w - lw_)):
                it.append((lw_ if i == 0 else 0, y, F["body"], TEXT, z))
                y += lh(F["body"])
        elif k == "wahl":
            dk.append(("pfeil", 0, 7))
            for z in umbrechen(F["small"], self.data, w - 18):
                it.append((18, y, F["small"], DIM, z))
                y += lh(F["small"])
        elif k == "member":
            name, info, status_kind, leitung = self.data
            stil = NOTE_STIL[status_kind] if status_kind in NOTE_STIL else (status_kind.upper(), GREEN, TEXT)
            dk.append(("pille", 0, 1, stil[0], stil[1], LABEL_W))
            x0 = LABEL_W + 12
            it.append((x0, 0, F["bold"], TEXT, name))
            if leitung:
                dk.append(("pille", x0 + F["bold"].size(name)[0] + 10, 2, "LEITUNG", ACCENT, None))
            y = lh(F["bold"])
            for z in umbrechen(F["small"], info, w - x0):
                it.append((x0, y, F["small"], DIM, z))
                y += lh(F["small"])
        elif k == "ki":
            y = self._ki_layout(w, it)
        else:  # Notizen
            lab, lfarbe, tfarbe = NOTE_STIL.get(k, NOTE_STIL["info"])
            dk.append(("pille", 0, 2, lab, lfarbe, LABEL_W))
            x0 = LABEL_W + 12
            for z in umbrechen(F["note"], self.data, w - x0):
                it.append((x0, y, F["note"], tfarbe, z))
                y += lh(F["note"])
        self.items, self.deko, self.h = it, dk, max(y, 20)
        self.total = sum(len(i[4]) for i in it)
        if self.instant:
            self.shown = self.total

    def _ki_layout(self, w, it):
        y = 0
        erste = True
        for roh in self.data.split("\n"):
            s = roh.strip()
            if not s:
                if not erste:
                    y += 8
                continue
            erste = False
            if s.startswith("#"):
                y += 8
                for z in umbrechen(F["h2"], md_klar(s.lstrip("#").strip()), w):
                    it.append((0, y, F["h2"], ACCENT, z))
                    y += F["h2"].get_linesize() + 2
                y += 4
            elif s in ("---", "***", "___"):
                y += 10
            elif s.startswith(("- ", "* ", "• ")):
                it.append((4, y, F["body"], DIM, "•"))
                for z in umbrechen(F["body"], md_klar(s[2:]), w - 22):
                    it.append((22, y, F["body"], TEXT, z))
                    y += F["body"].get_linesize() + 2
            else:
                fett = s.startswith("**") and s.endswith("**") and len(s) > 4
                f = F["bold"] if fett else F["body"]
                farbe = ACCENT if s.upper().startswith("[GEFAHR]") else TEXT
                for z in umbrechen(f, md_klar(s), w):
                    it.append((0, y, f, farbe, z))
                    y += f.get_linesize() + 2
        return y

    def draw(self, surf, x, y):
        if self.shown > 0 or self.instant:
            for d in self.deko:
                if d[0] == "pille":
                    pille(surf, x + d[1], y + d[2], d[3], d[4], d[5])
                elif d[0] == "linie":
                    pygame.draw.line(surf, (60, 66, 96), (x, y + d[1]), (x + self.lw, y + d[1]), 1)
                elif d[0] == "raute":
                    cx, cy = x + d[1] + 4, y + d[2]
                    pygame.draw.polygon(surf, CYAN, [(cx, cy - 4), (cx + 4, cy), (cx, cy + 4), (cx - 4, cy)])
                elif d[0] == "pfeil":
                    cx, cy = x + d[1], y + d[2]
                    pygame.draw.polygon(surf, ACCENT, [(cx, cy - 5), (cx + 8, cy), (cx, cy + 5)])
                elif d[0] == "text":
                    surf.blit(txt(d[4], d[3], d[5]), (x + d[1], y + d[2]))
        rest = self.shown
        for ix, iy, f, farbe, s in self.items:
            if rest <= 0:
                break
            if rest >= len(s):
                surf.blit(txt(f, s, farbe), (x + ix, y + iy))
            else:
                surf.blit(f.render(s[:rest], True, farbe), (x + ix, y + iy))
            rest -= len(s)


# ───────────────────────────── Schnittstelle zum Story-Thread ─────────────────────────────

def schnappschuss(Z):
    if not Z:
        return None
    f, a, fr = engine.akte_daten(Z)
    return {"fakten": f, "aussagen": a, "fragen": fr, "tot": list(Z["tot"]),
            "leiter": engine.leiter(Z), "kapitel": Z.get("kapitel", 1)}


class GuiUI(engine.UI):
    def __init__(self, Z, modus):
        self.events = queue.Queue()
        self.inq = queue.Queue()
        self.Z = Z
        self.ki_stand = None
        self.modus = modus
        self.abgebrochen = False
        self.snap = schnappschuss(Z)

    def _post(self, *ev):
        if self.abgebrochen:
            raise engine.Abbruch()
        try:
            self.snap = schnappschuss(self.ki_stand or self.Z)
        except RuntimeError:
            pass
        self.events.put(ev)

    def _wait(self):
        v = self.inq.get()
        if v is ABBRUCH:
            raise engine.Abbruch()
        return v

    def title(self, sub):
        self._post("block", "title", sub)

    def ort(self, text):
        self._post("block", "ort", text)

    def say(self, text):
        self._post("block", "say", text)

    def talk(self, who, text):
        self._post("block", "talk", (who, text))

    def note(self, kind, text):
        self._post("block", kind, text)

    def pause(self):
        self._post("pause")
        return self._wait()

    def choose(self, options, Z, save=False):
        if Z is not None and Z is not self.Z and self.ki_stand is None:
            self.Z = Z
        self._post("choose", list(options), save)
        return self._wait()

    def ask_text(self, prompt, secret=False):
        self._post("ask", prompt, secret)
        return self._wait()

    def stream_begin(self):
        self._post("sbegin")

    def stream(self, chunk):
        self._post("schunk", chunk)

    def stream_end(self):
        self._post("send")

    def busy(self, text):
        self._post("busy", text)


# ───────────────────────────── Kulisse ─────────────────────────────

def kulisse():
    rng = random.Random(7)
    s = pygame.Surface((W, H))
    for y in range(H):
        t = y / H
        c = tuple(int(BG_TOP[i] * (1 - t) + BG_BOT[i] * t) for i in range(3))
        pygame.draw.line(s, c, (0, y), (W, y))
    wasser = H - 70
    x = -20
    while x < W:                                   # ferne Häuser
        bw, bh = rng.randint(40, 90), rng.randint(110, 280)
        pygame.draw.rect(s, (22, 24, 48), (x, wasser - bh, bw, bh))
        x += bw - rng.randint(0, 10)
    x = -10
    while x < W:                                   # nahe Häuser mit Fenstern
        bw, bh = rng.randint(50, 120), rng.randint(140, 420)
        pygame.draw.rect(s, (12, 13, 28), (x, wasser - bh, bw, bh))
        for wy in range(wasser - bh + 12, wasser - 10, 14):
            for wx in range(x + 8, x + bw - 8, 11):
                if rng.random() < 0.18:
                    farbe = (255, 196, 110) if rng.random() < 0.8 else (120, 210, 240)
                    pygame.draw.rect(s, farbe, (wx, wy, 4, 6))
        if rng.random() < 0.25:                    # Leuchtschrift
            pygame.draw.rect(s, (255, 90, 120), (x + 6, wasser - bh - 10, bw - 12, 4))
        x += bw + rng.randint(4, 30)
    # Hafenkran am Westkai
    k = (8, 9, 20)
    pygame.draw.rect(s, k, (1120, wasser - 260, 10, 260))
    pygame.draw.line(s, k, (1040, wasser - 250), (1270, wasser - 250), 6)
    pygame.draw.line(s, k, (1125, wasser - 300), (1060, wasser - 252), 3)
    pygame.draw.line(s, k, (1125, wasser - 300), (1250, wasser - 252), 3)
    pygame.draw.line(s, k, (1210, wasser - 250), (1210, wasser - 170), 1)
    pygame.draw.rect(s, (14, 16, 30), (0, wasser, W, H - wasser))
    for _ in range(140):                           # Spiegelungen
        xx, yy = rng.randint(0, W), rng.randint(wasser + 4, H - 4)
        pygame.draw.line(s, (90, 76, 60), (xx, yy), (xx + rng.randint(6, 30), yy), 1)
    return s


def mond():
    m = pygame.Surface((260, 260), pygame.SRCALPHA)
    for r in range(126, 26, -4):                   # weicher Hof, innen heller
        pygame.draw.circle(m, (200, 210, 255, int(2 + (126 - r) * 0.3)), (130, 130), r)
    pygame.draw.circle(m, (232, 228, 214, 255), (130, 130), 26)
    pygame.draw.circle(m, (214, 210, 196, 255), (122, 124), 6)
    pygame.draw.circle(m, (214, 210, 196, 255), (138, 138), 4)
    return m


def ohne_optionen(text):
    """Entfernt die nummerierten Optionen am Ende einer KI-Antwort (sie stehen als Knöpfe darunter)."""
    if not ki.optionen(text):
        return text
    zeilen = text.rstrip().split("\n")
    while zeilen and (ki.OPT_RE.match(zeilen[-1]) or not zeilen[-1].strip()):
        zeilen.pop()
    return "\n".join(zeilen)


# ───────────────────────────── Anwendung ─────────────────────────────

class App:
    def __init__(self, screen):
        self.screen = screen
        self.bg = kulisse()
        self.mond = mond()
        self.panel = pygame.Surface(MAIN.size, pygame.SRCALPHA)
        rrect(self.panel, PANEL, self.panel.get_rect(), 16)
        self.side = pygame.Surface(SIDE.size, pygame.SRCALPHA)
        rrect(self.side, PANEL, self.side.get_rect(), 16)
        self.view = None
        self.regen = [[random.randint(0, W), random.randint(0, H), random.randint(9, 16)] for _ in range(110)]
        self.regen_layer = pygame.Surface((W, H), pygame.SRCALPHA)
        self.t = 0.0
        self.running = True
        self.toast, self.toast_t = "", 0.0
        self.mouse = (0, 0)
        self.menue_betreten()

    # ── Menü ──
    def menue_betreten(self):
        self.state = "menu"
        self.ui = None
        self.overlay = None
        self.neu_bestaetigen = False
        self.menue_aufbauen()
        try:
            pygame.key.stop_text_input()
        except Exception:
            pass

    def menue_aufbauen(self):
        Z = engine.laden()
        self.menue_Z = Z
        e = []
        if Z and Z.get("phase") != "spielende" and Z["kapitel"] <= 3:
            e.append(("weiter", f"Fortsetzen – {engine.spielstand_info(Z)}"))
        e.append(("neu", "Wirklich neu beginnen? Der Spielstand wird überschrieben" if self.neu_bestaetigen
                  else "Neues Spiel – Kapitel 1 bis 3"))
        if ki.verlauf_laden():
            e.append(("ki_weiter", "KI-Erzähler fortsetzen"))
        mit = Z and (Z["kapitel"] > 1 or Z.get("done"))
        e.append(("ki_neu", "KI-Erzähler neu starten" + (" – mit deinem Spielstand" if mit else "")))
        e.append(("ende", "Beenden"))
        self.menue = e
        self.menue_rects = []
        y = 330
        for _ in e:
            self.menue_rects.append(pygame.Rect(96, y, 520, 50))
            y += 60

    def menue_aktion(self, k):
        Z = self.menue_Z
        if k == "ende":
            self.running = False
        elif k == "neu":
            if Z and Z.get("phase") != "spielende" and Z["kapitel"] <= 3 and not self.neu_bestaetigen:
                self.neu_bestaetigen = True
                self.menue_aufbauen()
                return
            Z = engine.neu()
            engine.speichern(Z)
            self.session_start("spiel", Z)
        elif k == "weiter":
            self.session_start("spiel", Z)
        elif k == "ki_weiter":
            self.session_start("ki_weiter", Z)
        elif k == "ki_neu":
            self.session_start("ki_neu", Z)

    # ── Sitzung ──
    def session_start(self, art, Z):
        modus = "Spiel" if art == "spiel" else "KI"
        self.ui = GuiUI(Z, modus)
        self.blocks, self.pending, self.save_ok = [], None, False
        self.busy_text, self.stream_block = "", None
        self.scroll, self.follow = 0, True
        self.overlay, self.eingabe = None, ""
        self.buttons = []
        self.state = "game"

        def lauf(ui=self.ui):
            try:
                if art == "spiel":
                    Zs = engine.spiel(ui, Z)
                    if Zs["kapitel"] > 3 and Zs.get("phase") != "spielende":
                        if ui.choose(["Mit dem KI-Erzähler weiterspielen", "Zurück zum Hauptmenü"], Zs) == 0:
                            ui.modus = "KI"
                            ki.sitzung(ui, Zs, neu=True)
                else:
                    ki.sitzung(ui, Z, neu=(art == "ki_neu"))
            except engine.Abbruch:
                return
            except Exception:
                tb = traceback.format_exc()
                print(tb)
                try:
                    ui.note("warn", "Programmfehler: " + tb.strip().splitlines()[-1])
                except engine.Abbruch:
                    return
            try:
                ui._post("ende")
            except engine.Abbruch:
                pass

        threading.Thread(target=lauf, daemon=True).start()

    def session_abbrechen(self):
        if self.ui:
            self.ui.abgebrochen = True
            self.ui.inq.put(ABBRUCH)
        self.menue_betreten()

    def antworten(self, wert, wahl_text=None):
        if wahl_text is not None:
            self.blocks.append(Block("wahl", wahl_text.replace("[GEFAHR]", "Gefahr –").strip()))
        self.pending = None
        self.save_ok = False
        self.follow = True
        try:
            pygame.key.stop_text_input()
        except Exception:
            pass
        self.ui.inq.put(wert)

    def events_holen(self):
        if not self.ui:
            return
        while True:
            try:
                ev = self.ui.events.get_nowait()
            except queue.Empty:
                return
            typ = ev[0]
            if typ == "block":
                self.busy_text = ""
                self.blocks.append(Block(ev[1], ev[2]))
            elif typ == "pause":
                self.pending = ("pause",)
            elif typ == "choose":
                self.pending = ("choose", ev[1])
                self.save_ok = ev[2]
            elif typ == "ask":
                self.pending = ("ask", ev[1], ev[2])
                self.eingabe = ""
                try:
                    pygame.key.start_text_input()
                except Exception:
                    pass
            elif typ == "busy":
                self.busy_text = ev[1]
            elif typ == "sbegin":
                self.busy_text = ""
                self.stream_block = Block("ki", "")
                self.blocks.append(self.stream_block)
            elif typ == "schunk":
                if self.stream_block:
                    self.stream_block.data += ev[1]
                    self.stream_block.dirty = True
            elif typ == "send":
                if self.stream_block:
                    self.stream_block.data = ohne_optionen(self.stream_block.data)
                    self.stream_block.dirty = True
                self.stream_block = None
            elif typ == "ende":
                self.pending = ("ende",)

    def alles_gezeigt(self):
        return all(b.shown >= b.total for b in self.blocks)

    def alles_zeigen(self):
        for b in self.blocks:
            b.layout(TW)
            b.shown = b.total

    # ── Steuerung unten ──
    def steuerung_layout(self):
        """Berechnet Buttons der unteren Steuerleiste. Gibt deren Höhe zurück."""
        self.buttons = []
        p = self.pending
        if self.busy_text and not p:
            return 44
        if not p or not self.alles_gezeigt():
            return 0
        unten = MAIN.bottom - 20
        if p[0] == "pause":
            r = pygame.Rect(TX + TW - 200, unten - 44, 200, 44)
            self.buttons.append(("pause", r, "Weiter", None))
            return 60
        if p[0] == "ende":
            r = pygame.Rect(TX + TW - 300, unten - 44, 300, 44)
            self.buttons.append(("ende", r, "Zurück zum Hauptmenü", None))
            return 60
        if p[0] == "ask":
            return 124
        if p[0] == "choose":
            hoehen = []
            for i, o in enumerate(p[1]):
                zeilen = umbrechen(F["btn"], o.replace("[GEFAHR]", "").strip(), TW - 72 - (82 if "[GEFAHR]" in o else 0))
                hoehen.append((zeilen, max(44, 14 + len(zeilen) * (F["btn"].get_linesize() + 1) + 10)))
            gesamt = sum(h for _, h in hoehen) + 8 * (len(hoehen) - 1)
            y = unten - gesamt
            for i, (zeilen, h) in enumerate(hoehen):
                self.buttons.append(("wahl", pygame.Rect(TX, y, TW, h), zeilen, i))
                y += h + 8
            return gesamt + 30
        return 0

    def steuerung_zeichnen(self, surf):
        p = self.pending
        if self.busy_text and not p:
            punkte = "." * (1 + int(self.t * 2.5) % 3)
            surf.blit(txt(F["smallb"], self.busy_text.rstrip(" …") + " " + punkte, ACCENT), (TX, MAIN.bottom - 52))
            return
        for art, r, inhalt, idx in self.buttons:
            hover = r.collidepoint(self.mouse)
            rrect(surf, BTN_HI if hover else BTN, r, 10)
            rrect(surf, ACCENT if hover else BTN_RAND, r, 10, 1)
            if art == "wahl":
                opt = p[1][idx]
                gefahr = "[GEFAHR]" in opt
                badge = pygame.Rect(r.x + 12, r.y + 11, 26, 22)
                rrect(surf, ACCENT if not gefahr else RED, badge, 6)
                n = txt(F["btnb"], str(idx + 1), (12, 14, 24))
                surf.blit(n, (badge.centerx - n.get_width() // 2, badge.centery - n.get_height() // 2))
                x = r.x + 52
                if gefahr:
                    pille(surf, x, r.y + 12, "GEFAHR", RED, 72)
                    x += 82
                yy = r.y + 12
                for z in inhalt:
                    surf.blit(txt(F["btn"], z, TEXT), (x, yy))
                    yy += F["btn"].get_linesize() + 1
            else:
                t = txt(F["btnb"], inhalt, TEXT)
                surf.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))
                if art == "pause":
                    h = txt(F["small"], "Leertaste", DIM)
                    surf.blit(h, (r.x - h.get_width() - 14, r.centery - h.get_height() // 2))
        if p and p[0] == "ask" and self.alles_gezeigt():
            unten = MAIN.bottom - 20
            surf.blit(txt(F["smallb"], p[1], ACCENT), (TX, unten - 98))
            feld = pygame.Rect(TX, unten - 64, TW, 44)
            rrect(surf, (16, 18, 32), feld, 10)
            rrect(surf, ACCENT, feld, 10, 1)
            zeige = ("•" * len(self.eingabe)) if p[2] else self.eingabe
            while zeige and F["body"].size(zeige)[0] > TW - 40:
                zeige = zeige[1:]
            cursor = "|" if int(self.t * 2) % 2 == 0 else " "
            surf.blit(F["body"].render(zeige + cursor, True, TEXT), (feld.x + 14, feld.y + 10))
            surf.blit(txt(F["small"], "Enter senden · Strg+V einfügen · Esc Hauptmenü", DIM), (TX, unten - 14))

    # ── Seitenleiste ──
    def seitenleiste(self, surf):
        surf.blit(self.side, SIDE.topleft)
        x, y = SIDE.x + 22, SIDE.y + 22
        snap = self.ui.snap if self.ui else None
        surf.blit(txt(F["label"], "MERCER UNIT", ACCENT), (x, y))
        y += 24
        tot = snap["tot"] if snap else []
        leiter = snap["leiter"] if snap else "Daniel"
        for k, n in TEAM.items():
            name, code = n.split(" / ")
            farbe = RED if k in tot else GREEN
            pygame.draw.circle(surf, farbe, (x + 6, y + 10), 5)
            surf.blit(txt(F["smallb"], name, TEXT if k not in tot else DIM), (x + 20, y))
            surf.blit(txt(F["small"], code + ("  †" if k in tot else ""), DIM), (x + 20, y + 18))
            if k == leiter:
                pille(surf, SIDE.right - 98, y + 8, "LEITUNG", ACCENT, 76)
            y += 42
        y += 6
        pygame.draw.line(surf, (50, 56, 84), (x, y), (SIDE.right - 22, y))
        y += 14
        surf.blit(txt(F["label"], "FALL: HAFENGLOCKE" if (self.ui and self.ui.modus == "Spiel") else "KI-ERZÄHLER", ACCENT), (x, y))
        y += 22
        if snap:
            kap = snap["kapitel"]
            zeile = "Fall abgeschlossen" if kap > 3 else f"Kapitel {kap}: {engine.KAPITEL_TITEL.get(kap, '')}"
            surf.blit(txt(F["small"], zeile, TEXT), (x, y))
            y += 24
            g = sum(1 for st, _, _ in snap["fragen"] if st == "geklärt")
            for lab, wert in (("Beweise", len(snap["fakten"])), ("Aussagen", len(snap["aussagen"])),
                              ("Fragen geklärt", f"{g} / 6")):
                surf.blit(txt(F["small"], lab, DIM), (x, y))
                w_ = txt(F["smallb"], str(wert), TEXT)
                surf.blit(w_, (SIDE.right - 22 - w_.get_width(), y))
                y += 22
            bar = pygame.Rect(x, y + 4, SIDE.w - 44, 6)
            rrect(surf, (40, 44, 70), bar, 3)
            if g:
                rrect(surf, GREEN, pygame.Rect(bar.x, bar.y, int(bar.w * g / 6), 6), 3)
        # Knöpfe
        self.side_buttons = []
        by = SIDE.bottom - 22 - 2 * 44 - 10
        knoepfe = [("akte", "Fallakte  [A]"), ("team", "Team  [T]"),
                   ("save", "Speichern  [S]"), ("menu", "Hauptmenü  [Esc]")]
        for i, (k, lab) in enumerate(knoepfe):
            bw = (SIDE.w - 44 - 10) // 2
            r = pygame.Rect(x + (i % 2) * (bw + 10), by + (i // 2) * 54, bw, 44)
            aktiv = k != "save" or (self.save_ok and self.alles_gezeigt())
            hover = aktiv and r.collidepoint(self.mouse)
            rrect(surf, BTN_HI if hover else BTN, r, 10)
            rrect(surf, ACCENT if hover else BTN_RAND, r, 10, 1)
            t = txt(F["small"], lab, TEXT if aktiv else (80, 86, 108))
            surf.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))
            self.side_buttons.append((k, r, aktiv))
        if self.toast and self.t < self.toast_t:
            t = txt(F["smallb"], self.toast, GREEN)
            surf.blit(t, (SIDE.centerx - t.get_width() // 2, by - 30))

    # ── Overlays ──
    def overlay_oeffnen(self, art):
        snap = self.ui.snap if self.ui else None
        bl = []
        if art == "akte":
            bl.append(Block("title", "Fallakte: Hafenglocke"))
            if snap:
                bl.append(Block("kopf", "Bewiesene Fakten"))
                bl += [Block("fakt", t) for t in snap["fakten"]]
                bl.append(Block("kopf", "Aussagen – nicht bewiesen"))
                bl += [Block("aussage", t) for t in snap["aussagen"]]
                bl.append(Block("kopf", "Kernfragen"))
                bl += [Block(st, q + (f" – {n}" if n else "")) for st, q, n in snap["fragen"]]
        else:
            bl.append(Block("title", "Die Mercer Unit"))
            tot = snap["tot"] if snap else []
            leiter = snap["leiter"] if snap else "Daniel"
            for k, n in TEAM.items():
                st = "tod" if k in tot else "einsatzbereit"
                bl.append(Block("member", (n, SKILL[k], st, k == leiter)))
            bl.append(Block("info", "Theo Alvarez / Relay – keine Superkräfte; Drohnen, Sensoren und Kommunikation. Nicht im Feld."))
            bl.append(Block("info", "In Erinnerung: Priya Nair / Liminal."))
        for b in bl:
            b.instant = True
        self.overlay = {"art": art, "blocks": bl, "scroll": 0}

    def overlay_zeichnen(self, surf):
        dunkel = pygame.Surface((W, H), pygame.SRCALPHA)
        dunkel.fill((0, 0, 0, 160))
        surf.blit(dunkel, (0, 0))
        r = pygame.Rect(120, 40, W - 240, H - 80)
        box = pygame.Surface(r.size, pygame.SRCALPHA)
        rrect(box, (12, 14, 28, 245), box.get_rect(), 16)
        rrect(box, (60, 68, 100, 255), box.get_rect(), 16, 1)
        vw, vh = r.w - 100, r.h - 70
        inner = pygame.Surface((vw, vh), pygame.SRCALPHA)
        y = -self.overlay["scroll"]
        for b in self.overlay["blocks"]:
            b.layout(vw)
            y += b.top
            if -b.h - 40 < y < vh:
                b.draw(inner, 0, y)
            y += b.h
        self.overlay["max"] = max(0, y + self.overlay["scroll"] - vh + 20)
        box.blit(inner, (50, 36))
        hint = txt(F["small"], "Esc schließen · Mausrad scrollen", DIM)
        box.blit(hint, (r.w - hint.get_width() - 24, r.h - 28))
        surf.blit(box, r.topleft)
        self.overlay_rect = r

    # ── Hauptschleife ──
    def update(self, dt):
        self.t += dt
        if self.state != "game":
            return
        self.events_holen()
        budget = int(dt * 1300) + 1
        for b in self.blocks:
            b.layout(TW)
            if b.shown < b.total:
                n = min(budget, b.total - b.shown)
                b.shown += n
                budget -= n
                if budget <= 0:
                    break

    def draw(self):
        s = self.screen
        s.blit(self.bg, (0, 0))
        # Regen und Kranlicht
        rl = self.regen_layer
        rl.fill((0, 0, 0, 0))
        for d in self.regen:
            d[1] += d[2]
            d[0] -= 1
            if d[1] > H:
                d[0], d[1] = random.randint(0, W + 100), -20
            pygame.draw.line(rl, (150, 170, 220, 60), (d[0], d[1]), (d[0] - 2, d[1] + 12), 1)
        blink = int(150 + 105 * math.sin(self.t * 3))
        pygame.draw.circle(rl, (255, 60, 60, blink), (1125, H - 70 - 302), 4)
        s.blit(rl, (0, 0))
        if self.state == "menu":
            self.menue_zeichnen(s)
        else:
            self.spiel_zeichnen(s)
        pygame.display.flip()

    def menue_zeichnen(self, s):
        s.blit(self.mond, (880, -10))
        p = pygame.Surface((740, 560), pygame.SRCALPHA)
        rrect(p, (8, 10, 20, 200), p.get_rect(), 18)
        s.blit(p, (60, 80))
        x = 96
        for i, ch in enumerate("AFTERHOURS"):
            g = txt(F["huge"], ch, ACCENT)
            s.blit(g, (x, 120))
            x += g.get_width() + 6
        s.blit(txt(F["h2"], "Vesper City · Die gestohlene Hafenglocke", TEXT), (98, 228))
        s.blit(txt(F["small"], "Eine interaktive Superhelden-Ermittlung in drei Kapiteln – und danach so weit, wie der KI-Erzähler trägt.", DIM), (98, 266))
        for i, ((k, lab), r) in enumerate(zip(self.menue, self.menue_rects)):
            hover = r.collidepoint(self.mouse)
            rrect(s, BTN_HI if hover else BTN, r, 12)
            rrect(s, ACCENT if hover else BTN_RAND, r, 12, 1)
            farbe = RED if (k == "neu" and self.neu_bestaetigen) else TEXT
            s.blit(txt(F["btnb"], f"{i + 1}", ACCENT), (r.x + 18, r.centery - 11))
            s.blit(txt(F["btn"], lab, farbe), (r.x + 48, r.centery - 11))
        s.blit(txt(F["small"], "Zahlen wählen · Leertaste weiter · A Fallakte · T Team · S Speichern · Esc Hauptmenü", DIM), (98, H - 60))

    def spiel_zeichnen(self, s):
        s.blit(self.panel, MAIN.topleft)
        ctrl_h = self.steuerung_layout()
        top = MAIN.y + 16
        vh = max(80, MAIN.bottom - ctrl_h - 14 - top)
        if self.view is None or self.view.get_size() != (TW + 40, vh):
            self.view = pygame.Surface((TW + 40, vh), pygame.SRCALPHA)
        v = self.view
        v.fill((0, 0, 0, 0))
        gesamt = 0
        for b in self.blocks:
            b.layout(TW)
            gesamt += b.top + b.h
        gesamt += 16
        maxs = max(0, gesamt - vh)
        if self.follow:
            self.scroll = maxs
        self.scroll = max(0, min(self.scroll, maxs))
        if self.scroll >= maxs - 2:
            self.follow = True
        y = -self.scroll
        for b in self.blocks:
            y += b.top
            if y + b.h > -10 and y < vh + 10:
                b.draw(v, 20, y)
            y += b.h
            if y > vh + 400:
                break
        s.blit(v, (TX - 20, top))
        if maxs > 0:                               # Scrollleiste
            bar_h = max(30, int(vh * vh / gesamt))
            by = top + int((vh - bar_h) * (self.scroll / maxs))
            rrect(s, (70, 78, 110), pygame.Rect(MAIN.right - 12, by, 4, bar_h), 2)
        if ctrl_h:
            pygame.draw.line(s, (40, 46, 72), (TX, MAIN.bottom - ctrl_h), (TX + TW, MAIN.bottom - ctrl_h))
        self.steuerung_zeichnen(s)
        self.seitenleiste(s)
        if self.overlay:
            self.overlay_zeichnen(s)

    # ── Eingaben ──
    def handle(self, ev):
        if ev.type == pygame.QUIT:
            self.running = False
            return
        if ev.type == pygame.MOUSEMOTION:
            self.mouse = ev.pos
            return
        if self.state == "menu":
            self.menue_event(ev)
        else:
            self.spiel_event(ev)

    def menue_event(self, ev):
        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            for (k, _), r in zip(self.menue, self.menue_rects):
                if r.collidepoint(ev.pos):
                    self.menue_aktion(k)
                    return
        elif ev.type == pygame.KEYDOWN:
            if pygame.K_1 <= ev.key <= pygame.K_9:
                i = ev.key - pygame.K_1
                if i < len(self.menue):
                    self.menue_aktion(self.menue[i][0])
            elif ev.key == pygame.K_ESCAPE:
                self.running = False

    def spiel_event(self, ev):
        p = self.pending
        if self.overlay:
            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_ESCAPE, pygame.K_a, pygame.K_t, pygame.K_RETURN, pygame.K_SPACE):
                self.overlay = None
            elif ev.type == pygame.MOUSEWHEEL:
                self.overlay["scroll"] = max(0, min(self.overlay.get("max", 0), self.overlay["scroll"] - ev.y * 50))
            elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1 and not self.overlay_rect.collidepoint(ev.pos):
                self.overlay = None
            return
        if ev.type == pygame.MOUSEWHEEL:
            self.scroll -= ev.y * 60
            if ev.y > 0:
                self.follow = False
            return
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_ESCAPE:
                self.session_abbrechen()
                return
            if p and p[0] == "ask" and self.alles_gezeigt():
                self.text_taste(ev)
                return
            if ev.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                if not self.alles_gezeigt():
                    self.alles_zeigen()
                elif p and p[0] == "pause":
                    self.antworten(None)
                elif p and p[0] == "ende":
                    self.menue_betreten()
            elif ev.key == pygame.K_a:
                self.overlay_oeffnen("akte")
            elif ev.key == pygame.K_t:
                self.overlay_oeffnen("team")
            elif ev.key == pygame.K_s:
                self.speichern()
            elif ev.key in (pygame.K_PAGEUP, pygame.K_UP):
                self.scroll -= 300 if ev.key == pygame.K_PAGEUP else 60
                self.follow = False
            elif ev.key in (pygame.K_PAGEDOWN, pygame.K_DOWN):
                self.scroll += 300 if ev.key == pygame.K_PAGEDOWN else 60
            elif pygame.K_1 <= ev.key <= pygame.K_9 and p and p[0] == "choose" and self.alles_gezeigt():
                i = ev.key - pygame.K_1
                if i < len(p[1]):
                    self.antworten(i, p[1][i])
            return
        if ev.type == pygame.TEXTINPUT and p and p[0] == "ask":
            self.eingabe += ev.text
            return
        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            for k, r, aktiv in getattr(self, "side_buttons", []):
                if aktiv and r.collidepoint(ev.pos):
                    {"akte": lambda: self.overlay_oeffnen("akte"), "team": lambda: self.overlay_oeffnen("team"),
                     "save": self.speichern, "menu": self.session_abbrechen}[k]()
                    return
            for art, r, inhalt, idx in self.buttons:
                if r.collidepoint(ev.pos):
                    if art == "wahl":
                        self.antworten(idx, p[1][idx])
                    elif art == "pause":
                        self.antworten(None)
                    elif art == "ende":
                        self.menue_betreten()
                    return
            if MAIN.collidepoint(ev.pos):
                if not self.alles_gezeigt():
                    self.alles_zeigen()
                elif p and p[0] == "pause":
                    self.antworten(None)

    def text_taste(self, ev):
        mods = pygame.key.get_mods()
        if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            wert = self.eingabe
            secret = self.pending[2]
            self.antworten(wert, None if secret or not wert.strip() else "Eigene Eingabe: " + wert)
        elif ev.key == pygame.K_BACKSPACE:
            self.eingabe = self.eingabe[:-1]
        elif ev.key == pygame.K_v and (mods & (pygame.KMOD_CTRL | pygame.KMOD_META)):
            self.eingabe += zwischenablage().replace("\r", "").replace("\n", " ")

    def speichern(self):
        if self.save_ok and self.alles_gezeigt() and self.ui and self.ui.modus == "Spiel":
            engine.speichern(self.ui.Z)
            self.toast, self.toast_t = "Spielstand gespeichert", self.t + 2.5


def zwischenablage():
    try:
        if hasattr(pygame.scrap, "get_text"):
            t = pygame.scrap.get_text()
            if t:
                return t
    except Exception:
        pass
    try:
        pygame.scrap.init()
        raw = pygame.scrap.get(pygame.SCRAP_TEXT)
        if raw:
            return raw.decode("utf-8", "ignore").rstrip("\x00")
    except Exception:
        pass
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        t = r.clipboard_get()
        r.destroy()
        return t
    except Exception:
        return ""


def main():
    pygame.init()
    flags = 0
    try:
        info = pygame.display.Info()
        if info.current_w and (info.current_w < W + 40 or info.current_h < H + 80):
            flags = pygame.SCALED
    except Exception:
        pass
    screen = pygame.display.set_mode((W, H), flags)
    pygame.display.set_caption("AFTERHOURS – Vesper City")
    try:
        pygame.key.set_repeat(400, 35)
    except Exception:
        pass
    schriften_laden()
    app = App(screen)
    clock = pygame.time.Clock()
    while app.running:
        dt = clock.tick(60) / 1000.0
        for ev in pygame.event.get():
            app.handle(ev)
        app.update(dt)
        app.draw()
    pygame.quit()


if __name__ == "__main__":
    main()
