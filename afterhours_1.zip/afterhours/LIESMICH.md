# AFTERHOURS – Vesper City

Interaktive Superhelden-Ermittlung in Python, gebaut nach deinem Projektprompt.

## Starten

```
pip install pygame
python afterhours.py
```

Ohne pygame startet automatisch die Terminalversion. Die Terminalversion kannst du auch direkt starten:

```
python afterhours.py --terminal
```

Voraussetzung: Python 3.8 oder neuer. Für die Grafikversion zusätzlich pygame 2.

## Selbsttest

```
python afterhours.py --selbsttest
```

Prüft auf deinem Rechner in etwa einer Minute:

- die Geschichte mit 300 automatischen Durchläufen,
- die Grafikversion mit echtem pygame in einem unsichtbaren Fenster,
- die Verbindung zur Claude-API, falls ein Schlüssel eingerichtet ist (kostet nur eine Mini-Anfrage).

Dein Spielstand bleibt unberührt. Die Bildschirmfotos landen in `selbsttest_bilder/`. Wenn etwas fehlschlägt, kopiere die Ausgabe in den Chat.

## Was drin ist

**Drei Kapitel bis zum Abschluss des Hafenglocken-Falls**

1. *Die Reservierung*: Wer ist „E. V.“? Endet mit der kontrollierten Lieferung am Weidenhof 7.
2. *Drei Striche im Kreis*: Wer hat die Glocke aus dem Museum geholt? Endet mit dem Zugriff auf Vera Kess.
3. *Glockenschlag*: Der „Treuhänder“ Ivo Serrat. Endet mit dem Fallabschluss und der Glocke am Westkai.

Deine Entscheidungen bestimmen unter anderem:

- welche Beweise du findest,
- wer festgenommen wird oder entkommt,
- wie stark die Anklage am Ende ist.

**Grafikversion**

- Nächtliche Stadtkulisse mit Regen
- Text erscheint Zeichen für Zeichen
- Auswahl per Klick oder Zahlentaste
- Seitenleiste mit Teamstatus und Fallfortschritt
- Fallakte und Teamübersicht als eigene Ansichten

**KI-Erzähler**

Claude erzählt die Geschichte frei weiter. Dein Projektprompt (`prompt_afterhours.md`) dient dabei als Systemprompt. Nach Kapitel 3 übernimmt der KI-Erzähler deinen kompletten Spielstand:

- Fakten, Aussagen und offene Fragen
- gefallene Teammitglieder
- den nächsten Handlungsstrang, den du gewählt hast

Du kannst den KI-Erzähler auch direkt aus dem Hauptmenü starten.

## Tasten (Grafikversion)

| Taste | Wirkung |
|---|---|
| 1–9 oder Klick | Option wählen |
| Leertaste / Enter | weiter, Text sofort ganz anzeigen |
| A | Fallakte |
| T | Team |
| S | Speichern (in Lagebesprechungen) |
| Mausrad, Bild↑/↓ | zurückscrollen |
| Esc | Hauptmenü |

Zusätzlich speichert das Spiel automatisch zu Beginn jedes Kapitels.

## Gefährliche Missionen

Optionen mit **GEFAHR** sind die vereinbarte Todesmechanik. Nur dort können ein oder zwei der Helden sterben, die du ausgewählt hast.

Wie hoch das Risiko ist, hängt davon ab, ob deine Auswahl die gebrauchten Fähigkeiten abdeckt.

Stirbt die Leitung, übernimmt die nächste Person die Mercer Unit. In dieser Reihenfolge: Mara, Imani, Leila, Nico, Asha, Juno. Du spielst dann diese Figur weiter.

Im KI-Modus würfelt das Programm selbst und teilt Claude das Ergebnis mit. Claude darf niemanden eigenmächtig sterben lassen.

## KI-Erzähler einrichten

1. API-Schlüssel in der Claude Console erstellen: console.anthropic.com → API Keys. Die Nutzung wird pro Anfrage abgerechnet.
2. Beim ersten Start fragt das Spiel nach dem Schlüssel und bietet an, ihn in `einstellungen.json` zu speichern. Alternativ setzt du die Umgebungsvariable `ANTHROPIC_API_KEY`.
3. Optional: Modell ändern. Voreingestellt ist `claude-sonnet-5-5`. So stellst du ein anderes ein:
   ```json
   { "modell": "claude-opus-5-5" }
   ```
   Das kommt in `einstellungen.json`. Alternativ setzt du die Umgebungsvariable `AFTERHOURS_MODELL`.

Der Verlauf liegt in `ki_verlauf.json`. Mit „KI-Erzähler fortsetzen“ geht es dort weiter.

`prompt_afterhours.md` kannst du jederzeit bearbeiten. Die Änderungen gelten ab der nächsten Antwort.

## Dateien

| Datei | Inhalt |
|---|---|
| `afterhours.py` | Startdatei |
| `gui.py` | Grafikversion (pygame) |
| `terminal.py` | Terminalversion |
| `engine.py` | Spielstand, Fallakte, Team, Missionsmechanik |
| `kapitel1.py` bis `kapitel3.py` | die Geschichte |
| `ki.py` | KI-Erzähler (Claude-API, nur Standardbibliothek) |
| `selbsttest.py` | Selbsttest für Grafik, Geschichte und API |
| `prompt_afterhours.md` | dein Projektprompt |
| `spielstand.json`, `ki_verlauf.json`, `einstellungen.json` | entstehen beim Spielen |
